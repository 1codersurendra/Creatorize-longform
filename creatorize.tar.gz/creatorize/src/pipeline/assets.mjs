/**
 * Asset generation through Scenario's MCP server.
 *
 * Scenario carries 750+ models and a custom-model training loop. Creatorize
 * uses it for the two things a long-form episode needs most and that a
 * subscription-backed agent cannot supply: stills that prove a claim, and
 * thumbnails.
 *
 * The leg is optional by design. When no Scenario credential is present the
 * pipeline still runs: Hypit's own providers (GPT Image, Seedream, Seedance,
 * ElevenLabs, Fish Audio) and code-rendered visuals cover the same ground.
 * That is deliberate - it mirrors the "no external API" posture the channel
 * itself sells.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { ScenarioClient } from "../adapters/scenario.mjs";

const execFileAsync = promisify(execFile);

export class AssetGenerator {
  constructor({ client, dryRun = false } = {}) {
    this.client = client;
    this.dryRun = dryRun;
  }

  static async connect({ endpoint, accessToken, tokenStorePath, onAuthRequired, dryRun } = {}) {
    const client = await ScenarioClient.connect({
      endpoint,
      accessToken,
      tokenStorePath,
      onAuthRequired,
    });
    return new AssetGenerator({ client, dryRun });
  }

  get serverInfo() {
    return this.client?.serverInfo;
  }

  /**
   * Generate one B-roll still for a brief. Returns the written file path and
   * the raw Scenario result, so the agent can see what the model actually
   * produced rather than trusting a green checkmark.
   */
  async generateBroll(brief, { assetsDir, index = 0 }) {
    if (!this.client) throw new Error("Scenario is not connected.");
    if (this.dryRun) {
      return { id: brief.id, status: "skipped", reason: "dry run", prompt: buildPrompt(brief) };
    }

    const recommendation = await this.client.recommendModel(buildPrompt(brief), { domain: "image" }).catch(() => undefined);
    const model = pickModel(recommendation, brief);

    const result = await this.client.generate({
      prompt: buildPrompt(brief),
      model,
      domain: "image",
      options: {
        aspect_ratio: brief.aspectRatio ?? "16:9",
        negative_prompt: brief.negative,
      },
    });

    const assetUrl = extractAssetUrl(result);
    if (!assetUrl) {
      return { id: brief.id, status: "no-asset", model, result };
    }

    const filename = `${brief.id}${suffixFor(brief)}.png`;
    const target = join(assetsDir, filename);
    const bytes = await download(assetUrl);
    await writeFile(target, bytes);
    return { id: brief.id, status: "written", path: target, model, url: assetUrl };
  }

  /** Generate every B-roll brief in a plan. */
  async generatePlanBroll(plan, { assetsDir }) {
    await mkdir(assetsDir, { recursive: true });
    const briefs = plan.sections.flatMap((section) =>
      (section.broll ?? []).map((brief) => ({ ...brief, sectionId: section.id })),
    );
    const results = [];
    for (const [index, brief] of briefs.entries()) {
      const section = plan.sections.find((candidate) => candidate.id === brief.sectionId);
      const span = Math.max(1, Math.floor((section?.targetSeconds ?? 60) / Math.max(1, briefs.length)));
      try {
        const result = await this.generateBroll(brief, { assetsDir, index });
        results.push({
          ...result,
          sectionId: brief.sectionId,
          atSeconds: Math.min(index * span, Math.max(0, (section?.targetSeconds ?? 60) - 4)),
          durationSeconds: 4,
        });
      } catch (error) {
        results.push({ id: brief.id, sectionId: brief.sectionId, status: "error", error: error.message });
      }
    }
    return results;
  }

  /** Ask Scenario to write the episode thumbnail. */
  async generateThumbnail({ topic, title, assetsDir, reference = "g russ" }) {
    if (!this.client) throw new Error("Scenario is not connected.");
    if (this.dryRun) return { status: "skipped", reason: "dry run" };
    const prompt = [
      `A YouTube thumbnail for a long-form video about "${title ?? topic}".`,
      `High contrast, one clear focal idea, readable at small size, no small text.`,
      `Match the visual register of the channel "${reference}".`,
    ].join(" ");
    const result = await this.client.generate({ prompt, domain: "image" });
    const assetUrl = extractAssetUrl(result);
    if (!assetUrl) return { status: "no-asset", result };
    const target = join(assetsDir, "thumbnail.png");
    await writeFile(target, await download(assetUrl));
    return { status: "written", path: target, url: assetUrl };
  }
}

/**
 * Placeholder B-roll, rendered locally with ffmpeg.
 *
 * A picture track with no clips is not a film, and a creator should be able to
 * validate the whole chain - timeline, captions, cuts, export - before a
 * single generation credit is spent. These are grey slates with a timecode
 * burn-in: unmistakably placeholders, but real media.
 */
export async function generatePlaceholderBroll(plan, { assetsDir, durationSeconds = 4 } = {}) {
  await mkdir(assetsDir, { recursive: true });
  const results = [];
  for (const section of plan.sections) {
    const briefs = section.broll ?? [];
    const span = Math.max(1, Math.floor((section.targetSeconds ?? 60) / Math.max(1, briefs.length)));
    for (const [index, brief] of briefs.entries()) {
      const target = join(assetsDir, `${brief.id}.mp4`);
      const seconds = Math.max(2, Math.min(durationSeconds, span));
      await renderSlate(target, seconds, brief.id);
      results.push({
        id: brief.id,
        sectionId: section.id,
        atSeconds: Math.min(index * span, Math.max(0, (section.targetSeconds ?? 60) - seconds)),
        durationSeconds: seconds,
        path: target,
        status: "placeholder",
        brief: brief.brief,
      });
    }
  }
  return results;
}

async function renderSlate(target, seconds, label) {
  const drawtext = `text='${label}':fontcolor=white:fontsize=36:x=(w-text_w)/2:y=(h-text_h)/2`;
  await execFileAsync("ffmpeg", [
    "-y",
    "-f",
    "lavfi",
    "-i",
    `color=c=0x141821:s=1920x1080:r=30:d=${seconds}`,
    "-vf",
    `drawbox=x=0:y=0:w=iw:h=ih:color=0x1E2634@1:t=fill,drawtext=${drawtext}`,
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-pix_fmt",
    "yuv420p",
    "-t",
    String(seconds),
    target,
  ]);
}

function buildPrompt(brief) {
  return [
    brief.brief,
    brief.negative ? `Avoid: ${brief.negative}.` : undefined,
    `Aspect ratio ${brief.aspectRatio ?? "16:9"}.`,
  ]
    .filter(Boolean)
    .join(" ");
}

/** Read a model name out of Scenario's recommendation payload, if it has one. */
function pickModel(recommendation, brief) {
  const candidates = [
    recommendation?.normalized?.model,
    recommendation?.model,
    recommendation?.normalized?.recommended_model,
    recommendation?.recommended_model,
  ].filter(Boolean);
  if (candidates.length > 0) return typeof candidates[0] === "string" ? candidates[0] : candidates[0].name;
  return brief.model === "image" ? undefined : brief.model;
}

function extractAssetUrl(result) {
  const stack = [result];
  while (stack.length) {
    const current = stack.pop();
    if (!current) continue;
    if (typeof current === "string") {
      if (/^https?:\/\//.test(current) && /\.(png|jpe?g|webp|gif|mp4|webm|glb|gltf)(\?|$)/i.test(current)) {
        return current;
      }
      continue;
    }
    if (Array.isArray(current)) {
      stack.push(...current);
      continue;
    }
    if (typeof current === "object") {
      for (const key of ["url", "asset_url", "image_url", "video_url", "download_url", "signed_url", "uri"]) {
        const value = current[key];
        if (typeof value === "string" && /^https?:\/\//.test(value)) return value;
      }
      stack.push(...Object.values(current));
    }
  }
  return undefined;
}

async function download(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Asset download failed (${response.status}) for ${url}`);
  return Buffer.from(await response.arrayBuffer());
}

function suffixFor(brief) {
  return brief.kind === "video" ? ".mp4" : ".png";
}
