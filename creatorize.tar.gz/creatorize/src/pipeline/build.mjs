/**
 * Build: hand the authored project to Hypit and collect the render.
 *
 * The order matters. `check` validates the Source before anything is
 * generated, so a broken reference costs a second rather than a credit. Then
 * `build --follow` runs the production, and `get` exports the named Output.
 */
import { join } from "node:path";
import { projectLayout } from "./author.mjs";

export class Builder {
  constructor({ hypit, root, log = console.log }) {
    this.hypit = hypit;
    this.root = root;
    this.log = log;
  }

  layout() {
    return projectLayout(this.root);
  }

  /** Validate the Source. Cheap; run it on every change. */
  async check({ sourceFile = "episode.svml" } = {}) {
    const layout = this.layout();
    const source = join(layout.authors, sourceFile);
    this.log(`check ${source}`);
    const result = await this.hypit.check(source, { cwd: layout.root });
    return result;
  }

  /** Show what the Run will do without executing it. */
  async plan({ runFile = "episode.svrun" } = {}) {
    const layout = this.layout();
    const run = join(layout.runs, runFile);
    this.log(`plan ${run}`);
    return this.hypit.plan(run, { cwd: layout.root });
  }

  /** Execute the build and follow it to completion. */
  async build({ runFile = "episode.svrun", follow = true } = {}) {
    const layout = this.layout();
    const run = join(layout.runs, runFile);
    this.log(`build ${run}`);
    return this.hypit.build(run, { cwd: layout.root, follow });
  }

  /** Most recent builds, newest first. */
  async builds() {
    return this.hypit.builds({ cwd: this.root });
  }

  async status(buildId) {
    return this.hypit.status(buildId, { cwd: this.root });
  }

  async logs(buildId, lines = 200) {
    return this.hypit.logs(buildId, { cwd: this.root, lines });
  }

  /**
   * Export a finished Output. Hypit names Outputs by what they are, not by
   * what we asked for, so the caller usually wants the list first.
   */
  async outputs(buildId) {
    const result = await this.hypit.inspect(buildId, { cwd: this.root });
    return result;
  }

  async export(buildId, outputName, to) {
    const layout = this.layout();
    const target = to ?? join(layout.root, "out", outputName);
    this.log(`get ${buildId} --output ${outputName} --to ${target}`);
    return this.hypit.get(buildId, outputName, target, { cwd: layout.root });
  }

  /**
   * Full run: check, build, then export the first video Output we find.
   */
  async run({ runFile = "episode.svrun", output = "episode.mp4" } = {}) {
    await this.check({ sourceFile: "episode.svml" });
    const built = await this.build({ runFile });
    const buildId = extractBuildId(built);
    if (!buildId) {
      return { ok: false, stage: "build", reason: "Hypit did not report a build id.", raw: built.stdout };
    }
    this.log(`build ${buildId} finished`);
    const exported = await this.export(buildId, output, undefined).catch(async (error) => {
      // The Output may be named differently; report what the build actually has.
      const inspected = await this.outputs(buildId).catch(() => undefined);
      return { ok: false, stage: "export", error: error.message, inspected };
    });
    return { ok: true, buildId, exported };
  }
}

export function extractBuildId(result) {
  const data = result?.data;
  const candidates = [
    data?.build?.id,
    data?.build_id,
    data?.id,
    data?.builds?.[0]?.id,
    data?.results?.[0]?.build_id,
  ].filter(Boolean);
  if (candidates.length > 0) return candidates[0];
  const match = /bld_[A-Za-z0-9_]+/.exec(result?.stdout ?? "");
  return match?.[0];
}
