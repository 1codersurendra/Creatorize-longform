/**
 * Project dependencies.
 *
 * A Hypit project is an ordinary npm project that declares `hypit.project`.
 * The Surfaces a Source uses come from packages, so a project that imports
 * `@hypit/caption-fine` must have it installed - otherwise the Source fails
 * with a resolution error that reads like a bug in the Source rather than a
 * missing dependency.
 *
 * Creatorize keeps this list in one place so `creatorize init` and
 * `creatorize author` produce a project that runs.
 */
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";

const execFileAsync = promisify(execFile);

/**
 * The Hypit packages the generated long-form Source imports.
 *
 * `@hypit/text` and `@hypit/recipe` are not published on their own - they
 * arrive transitively - so they are deliberately absent here.
 */
export const HYPIT_PACKAGES = [
  "@hypit/media",
  "@hypit/visual-track",
  "@hypit/audio-track",
  "@hypit/caption",
  "@hypit/caption-fine",
  "@hypit/fontsource",
  "@hypit/spatial",
  "@hypit/timeline-author",
  "@hypit/film",
  "@hypit/html-video",
  "@hypit/script",
  "@hypit/whisperx",
  "@hypit/narrative-temporal",
  "@hypit/narrative-caption",
  "@hypit/media-operations",
  "@hypit/timeline",
  "@hypit/composition",
  "@hypit/temporal",
];

/** Fonts the caption system needs. */
export const FONT_PACKAGES = ["@fontsource-variable/inter"];

export const ALL_PACKAGES = [...HYPIT_PACKAGES, ...FONT_PACKAGES];

/**
 * Install the packages a project needs. Returns the packages that were
 * actually added, so the caller can report honestly.
 */
export async function installProjectDependencies(root, { packages = ALL_PACKAGES, log = console.log } = {}) {
  const manifestPath = join(root, "package.json");
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  const existing = Object.keys(manifest.dependencies ?? {});
  const missing = packages.filter((name) => !existing.includes(name));

  if (missing.length === 0) return { added: [], skipped: packages };

  log(`installing ${missing.length} package(s): ${missing.join(", ")}`);
  await execFileAsync("npm", ["install", "--no-audit", "--no-fund", "--ignore-scripts", ...missing], {
    cwd: root,
    timeout: 1800000,
    maxBuffer: 32 * 1024 * 1024,
  });
  return { added: missing, skipped: packages.filter((name) => existing.includes(name)) };
}

/** Record the dependencies in package.json without installing them. */
export async function declareDependencies(root, packages = ALL_PACKAGES) {
  const manifestPath = join(root, "package.json");
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  manifest.dependencies = { ...(manifest.dependencies ?? {}) };
  for (const name of packages) manifest.dependencies[name] = "latest";
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
  return Object.keys(manifest.dependencies);
}
