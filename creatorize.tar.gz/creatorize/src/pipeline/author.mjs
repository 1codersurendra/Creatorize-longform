/**
 * Author: turn a plan (plus a script) into a runnable Hypit project.
 *
 * The output is a real video project, not a sketch:
 *
 *   <project>/
 *     package.json          hypit.project: true
 *     authors/episode.svml  the Source
 *     recipes/longform.svs  the look
 *     runs/episode.svrun    the Run
 *     assets/               narration, B-roll, music
 *     creatorize.json       the plan and spec, so the next run knows itself
 */
import { mkdir, writeFile, readFile, readdir } from "node:fs/promises";
import { existsSync } from "node:fs";
import { join } from "node:path";
import { buildLongformSource, buildRecipeSheet, buildRun, buildRangeRun } from "../svml.mjs";
import { auditPlan } from "./plan.mjs";

export function projectLayout(root) {
  return {
    root,
    authors: join(root, "authors"),
    recipes: join(root, "recipes"),
    runs: join(root, "runs"),
    assets: join(root, "assets"),
    state: join(root, "creatorize.json"),
  };
}

/**
 * Read the B-roll manifest written by `creatorize assets`, if there is one.
 * Each entry becomes a clip in the picture track with a real placement.
 */
export async function readBrollManifest(root) {
  const path = join(root, "assets", "broll", "broll.json");
  if (!existsSync(path)) return [];
  try {
    const raw = JSON.parse(await readFile(path, "utf8"));
    return Array.isArray(raw) ? raw.filter((entry) => entry.path) : [];
  } catch {
    return [];
  }
}

export async function writeProject(root, plan, options = {}) {
  const layout = projectLayout(root);
  await Promise.all([
    mkdir(layout.authors, { recursive: true }),
    mkdir(layout.recipes, { recursive: true }),
    mkdir(layout.runs, { recursive: true }),
    mkdir(layout.assets, { recursive: true }),
  ]);

  const {
    longform = {},
    narrationDir = "../assets/narration",
    broll = [],
    extraAssets = [],
    recipeFile = "longform.svs",
    recipePath = `../recipes/${recipeFile}`,
    sourceFile = "episode.svml",
    runFile = "episode.svrun",
    output = "final.video",
  } = options;

  const sections = plan.sections.map((section) => ({
    id: section.id,
    spoken: section.spoken ?? "",
    role: section.role,
  }));

  // Paths inside a Source are relative to the Source, which lives in authors/.
  // Assets live in assets/, one level up.
  const manifest = broll.length === 0 ? await readBrollManifest(root) : broll;
  const sourceBroll = manifest.map((clip) => ({
    ...clip,
    src: clip.src ?? relativeFromAuthors(clip.path),
  }));
  const sourceAssets = extraAssets.map((asset) => ({
    ...asset,
    src: asset.src?.startsWith("./") ? `../${asset.src.slice(2)}` : asset.src,
  }));

  const source = buildLongformSource({
    name: plan.topic,
    sections,
    longform,
    recipeFile,
    recipePath,
    narrationDir,
    broll: sourceBroll,
    assets: sourceAssets,
  });

  const recipe = buildRecipeSheet({ background: longform.background ?? "#0B0D12" });
  const run = buildRun({ sourcePath: `../authors/${sourceFile}`, output });

  await writeFile(join(layout.authors, sourceFile), `${source}\n`, "utf8");
  await writeFile(join(layout.recipes, recipeFile), recipe, "utf8");
  await writeFile(join(layout.runs, runFile), run, "utf8");
  await writeFile(
    join(layout.root, "package.json"),
    `${JSON.stringify(
      {
        name: slugify(plan.topic) || "creatorize-episode",
        version: "0.0.0",
        private: true,
        type: "module",
        hypit: { project: true },
      },
      null,
      2,
    )}\n`,
    "utf8",
  );

  const state = {
    version: 1,
    createdAt: new Date().toISOString(),
    plan,
    files: {
      source: join(layout.authors, sourceFile),
      recipe: join(layout.recipes, recipeFile),
      run: join(layout.runs, runFile),
      narration: join(layout.assets, "narration"),
    },
    broll: broll.map((clip) => ({ id: clip.id, src: clip.src, sectionId: clip.sectionId })),
  };
  await writeFile(layout.state, `${JSON.stringify(state, null, 2)}\n`, "utf8");

  return { layout, audit: auditPlan(plan) };
}

/** Write a Run that renders only part of the timeline. */
export async function writeRangeRun(root, { from, to, output = "episode-part.mp4" }) {
  const layout = projectLayout(root);
  const run = buildRangeRun({ sourcePath: "../authors/episode.svml", output, from, to });
  const path = join(layout.runs, "episode-range.svrun");
  await writeFile(path, run, "utf8");
  return path;
}

/**
 * Write a Run that reuses an earlier build's transcription.
 *
 * This is the long-form iteration loop. The narration and its word timing are
 * the expensive part; the picture is cheap. A Run that satisfies the narration
 * media, its domain and its alignment from an earlier Result re-renders the
 * whole picture without asking the transcription service to do anything again.
 *
 * It also matters in practice: a long-form episode is re-cut many times, and
 * re-transcribing twenty-five minutes of narration for each change is the
 * difference between a ten-minute loop and a ten-second one.
 */
export async function writeReuseRun(root, buildId, sections, { sourceFile = "episode.svml", availableOutputs } = {}) {
  const layout = projectLayout(root);
  await mkdir(layout.runs, { recursive: true });
  const lines = [
    '<?svml using="@hypit/markup/run@1"?>',
    '<svrun version="1">',
    `  <author source="../authors/${sourceFile}"/>`,
    '  <target output="final.video"/>',
  ];

  const records = [];
  const missing = [];
  for (const section of sections) {
    for (const output of [
      `narration-${section.id}-media.media`,
      `narration-${section.id}-media.domain`,
      `align-${section.id}.alignment`,
    ]) {
      // An earlier build may have died part-way through. Claiming an Output
      // it never produced is a hard error, so only reuse what exists and let
      // the rest be produced again.
      if (availableOutputs && !availableOutputs.has(output)) {
        missing.push(output);
        continue;
      }
      const id = `kept-${output.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}`;
      lines.push(`  <build-record id="${id}" build="${buildId}" output="${output}"/>`);
      lines.push(`  <satisfy output="${output}" candidate="${id}"/>`);
      records.push({ id, output });
    }
  }
  lines.push("</svrun>", "");

  const path = join(layout.runs, "episode-reuse.svrun");
  await writeFile(path, lines.join("\n"), "utf8");
  return { path, records, missing };
}

/**
 * Write a Run that produces only the word alignments.
 *
 * Transcribing twenty-five minutes of narration and rasterising the picture
 * are different jobs with different memory profiles, and on a modest machine
 * they cannot share one process. A Run that targets the alignment Outputs
 * does the transcription and nothing else, so the picture can be rendered in
 * a second pass with the transcription service stopped.
 */
export async function writeAlignmentRun(root, sections, { sourceFile = "episode.svml" } = {}) {
  const layout = projectLayout(root);
  await mkdir(layout.runs, { recursive: true });
  const targets = sections.map((section) => `align-${section.id}.alignment`);
  const lines = [
    '<?svml using="@hypit/markup/run@1"?>',
    '<svrun version="1">',
    `  <author source="../authors/${sourceFile}"/>`,
    ...targets.map((output) => `  <target output="${output}"/>`),
    "</svrun>",
    "",
  ];
  const path = join(layout.runs, "episode-align.svrun");
  await writeFile(path, lines.join("\n"), "utf8");
  return { path, targets };
}

/** Read the public Outputs of an earlier build. */
export async function readBuildOutputs(root, buildId) {
  const resultsRoot = join(root, ".hypit", "results");
  const days = await readdir(resultsRoot).catch(() => []);
  for (const day of days.sort().reverse()) {
    const dir = join(resultsRoot, day, buildId);
    if (!existsSync(dir)) continue;
    const raw = await readFile(join(dir, "result.json"), "utf8").catch(() => undefined);
    if (!raw) continue;
    try {
      return new Set(Object.keys(JSON.parse(raw).outputs ?? {}));
    } catch {
      return new Set();
    }
  }
  return new Set();
}

/** Read a plan back out of a project. */
export async function readPlan(root) {
  const layout = projectLayout(root);
  const raw = await readFile(layout.state, "utf8");
  return JSON.parse(raw);
}

/** Apply a script to a plan: { sections: { id: "text" } }. */
export function applyScript(plan, script) {
  const next = structuredClone(plan);
  let applied = 0;
  for (const section of next.sections) {
    const text = script?.sections?.[section.id];
    if (typeof text === "string" && text.trim()) {
      section.spoken = text.trim();
      section.status = "scripted";
      applied += 1;
    }
  }
  return { plan: next, applied };
}

/** A path in the project, expressed relative to the Source in authors/. */
function relativeFromAuthors(path) {
  if (!path) return undefined;
  const normalized = String(path).replace(/\\/g, "/");
  const marker = "/assets/";
  const index = normalized.indexOf(marker);
  if (index >= 0) return `../assets/${normalized.slice(index + marker.length)}`;
  return normalized;
}

export function slugify(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}
