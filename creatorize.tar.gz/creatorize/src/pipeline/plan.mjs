/**
 * Long-form episode planning.
 *
 * The section templates below are not invented. They are reconstructed from
 * the channel's own published chapter lists:
 *
 *   "Opus 5.5 + Creatorize = LAZIEST Way to Make Money With AI" (17:44)
 *     Introduction / Philosophy and results / Routines overview / Setting up
 *     routines / Project creation and styles / Scripting and voiceover /
 *     Advanced automation / Building and editing / Quality control and
 *     refinement / Packaging and final output / Vertical and trailer
 *     automation / Community and conclusion
 *
 *   "Opus 5.5 + Creatorize = INSANE 3D Youtube Shorts" (17:08)
 *     Introduction / Demo / Manual vs AI / Starting a new project / Scripting
 *     and scene building / Testing performance / Advanced editing / case
 *     study / Pricing and final thoughts
 *
 *   "Creatorize + Claude = 26 Minute Documentaries For $0!" (34:04)
 *     Intro / What's new / What it is / The idea / The researched script /
 *     The voiceover / Setting up the project / The new look / The build
 *     direction / The crew build, live / The storyboard / The build numbers /
 *     The finished project / Variety / Checking a long video / Fixing things /
 *     Full-screen b-roll / Sound and export / Titles, description, chapters /
 *     What it costs / Tips for long videos / FAQ / The final video / The whole
 *     workflow / Outro
 *
 * Two spines are therefore real: TUTORIAL and DOCUMENTARY. A plan is the
 * chosen spine, filled for one topic, with per-section retention beats and
 * B-roll briefs.
 */

export const TEMPLATES = {
  tutorial: {
    label: "Tool tutorial / build-along",
    reference: "Creatorize long-form tool walkthroughs (17-18 minutes)",
    spine: [
      { id: "cold-open", role: "hook", title: "Introduction to {topic}", secondsShare: 0.035, purpose: "Show the finished result on screen before naming the tool. No logo, no greeting." },
      { id: "results", role: "promise", title: "Philosophy and results", secondsShare: 0.11, purpose: "State the outcome, the cost, and the time it takes. Give the viewer the reason to stay before the mechanics." },
      { id: "context", role: "context", title: "Manual vs AI content creation", secondsShare: 0.07, purpose: "Contrast the old way with the new way. This is where the viewer's doubt gets answered." },
      { id: "setup", role: "setup", title: "Setting up the project", secondsShare: 0.13, purpose: "Walk the setup screens. Name every control you touch." },
      { id: "scripting", role: "core", title: "Scripting and voiceover", secondsShare: 0.15, purpose: "The longest beat. Script, voice, and how the words drive the picture." },
      { id: "build", role: "core", title: "Building and editing", secondsShare: 0.17, purpose: "The build itself. Show the result appearing, not just the settings." },
      { id: "verify", role: "proof", title: "Quality control and refinement", secondsShare: 0.11, purpose: "Find the flaws on camera and fix them. This is what makes the rest credible." },
      { id: "case", role: "proof", title: "Case study", secondsShare: 0.11, purpose: "A second, different example that proves the method generalises." },
      { id: "output", role: "delivery", title: "Packaging and final output", secondsShare: 0.08, purpose: "Export settings, cost, and what to do with the file." },
      { id: "close", role: "cta", title: "Community and conclusion", secondsShare: 0.045, purpose: "Where to get it, what it costs, and the single next action." },
    ],
  },
  documentary: {
    label: "Faceless documentary / build-along",
    reference: "Creatorize long-form documentary (34 minutes)",
    spine: [
      { id: "cold-open", role: "hook", title: "Intro: a {duration} video made by AI", secondsShare: 0.04, purpose: "Open on the finished film or the strangest frame. State the claim in one sentence." },
      { id: "whats-new", role: "context", title: "What's new", secondsShare: 0.03, purpose: "The change that made this possible. One idea, no list." },
      { id: "what-it-is", role: "context", title: "What {tool} is", secondsShare: 0.04, purpose: "Define the thing in plain language. No vendor copy." },
      { id: "idea", role: "thesis", title: "The idea", secondsShare: 0.09, purpose: "The thesis of the episode, in one paragraph, stated plainly." },
      { id: "research", role: "core", title: "The researched script", secondsShare: 0.1, purpose: "Where the facts came from and how they were checked." },
      { id: "voiceover", role: "core", title: "The voiceover", secondsShare: 0.05, purpose: "The voice, cloned or recorded, and the direction given to it." },
      { id: "setup", role: "core", title: "Setting up the project", secondsShare: 0.08, purpose: "Project settings, style selection, canvas." },
      { id: "look", role: "core", title: "The new {style} look", secondsShare: 0.05, purpose: "Name the visual language and show three frames that prove it." },
      { id: "direction", role: "core", title: "The build direction", secondsShare: 0.05, purpose: "How the storyboard was authored, word by word." },
      { id: "build-live", role: "core", title: "The build, live", secondsShare: 0.1, purpose: "The long centrepiece. Uncut. Progress and problems both." },
      { id: "storyboard", role: "core", title: "The storyboard and the crew", secondsShare: 0.08, purpose: "Every scene the build produced, in order." },
      { id: "numbers", role: "proof", title: "The build numbers", secondsShare: 0.04, purpose: "Tokens, credits, minutes. Concrete figures, on screen." },
      { id: "finished", role: "proof", title: "The finished project", secondsShare: 0.05, purpose: "Watch a finished cut of the episode you are making." },
      { id: "variety", role: "core", title: "Variety: sets, light, people", secondsShare: 0.06, purpose: "How the same system produces different-looking films." },
      { id: "checking", role: "proof", title: "Checking a long video", secondsShare: 0.05, purpose: "The QA pass over the whole timeline." },
      { id: "fixing", role: "proof", title: "Fixing things like a human", secondsShare: 0.05, purpose: "Name three real problems and what changed." },
      { id: "broll", role: "core", title: "Full-screen b-roll", secondsShare: 0.05, purpose: "Where the B-roll comes from and how it is placed." },
      { id: "sound", role: "delivery", title: "Sound and export", secondsShare: 0.04, purpose: "Music, mix, and the export settings." },
      { id: "packaging", role: "delivery", title: "Titles, description, chapters", secondsShare: 0.03, purpose: "The upload metadata, including the chapter list." },
      { id: "cost", role: "proof", title: "What it costs", secondsShare: 0.02, purpose: "The real bill, to the credit." },
      { id: "tips", role: "value", title: "Tips for long videos", secondsShare: 0.03, purpose: "What to do differently next time. Specific, not generic." },
      { id: "faq", role: "value", title: "FAQ", secondsShare: 0.03, purpose: "The questions the comments will ask, answered before they ask." },
      { id: "workflow", role: "value", title: "The whole workflow", secondsShare: 0.03, purpose: "One continuous pass from topic to upload." },
      { id: "outro", role: "cta", title: "Outro", secondsShare: 0.02, purpose: "One call to action, one farewell." },
    ],
  },
};

const ROLE_INTENT = {
  hook: "Earn the next 20 seconds.",
  promise: "Make the payoff concrete before the mechanics.",
  context: "Remove the reason the viewer would click away.",
  thesis: "Say what the episode argues.",
  core: "Carry the episode's weight.",
  proof: "Make the claim believable.",
  value: "Give something the viewer can use.",
  delivery: "Get the work to the viewer.",
  cta: "Ask for exactly one action.",
};

export function listTemplates() {
  return Object.entries(TEMPLATES).map(([key, template]) => ({
    key,
    label: template.label,
    reference: template.reference,
    sections: template.spine.length,
  }));
}

/**
 * Build an episode plan.
 *
 * @param {object} options
 * @param {string} options.topic       the episode's subject
 * @param {string} [options.format]    "tutorial" | "documentary"
 * @param {string} [options.angle]     the one-sentence argument
 * @param {object} [options.spec]      the channel spec from analyze
 * @param {number} [options.seconds]   target runtime
 * @param {string[]} [options.chapters] a reference episode's own chapter titles
 */
export function buildPlan(options) {
  const {
    topic,
    format = "tutorial",
    angle,
    spec,
    seconds,
    tool = "the tool",
    style = "house",
    chapters = [],
  } = options;

  const template = TEMPLATES[format];
  if (!template) throw new Error(`Unknown format "${format}". Use: ${Object.keys(TEMPLATES).join(", ")}`);

  const targetSeconds = seconds ?? spec?.longform?.band?.recommendedTargetSeconds ?? 1500;
  const spine = template.spine;
  const rawWeights = spine.map((section) => section.secondsShare);
  const weightSum = rawWeights.reduce((sum, value) => sum + value, 0);
  const fills = {
    topic,
    tool,
    style,
    duration: formatRuntime(targetSeconds),
    minutes: Math.round(targetSeconds / 60),
  };

  const sections = spine.map((section, index) => {
    const target = Math.round((section.secondsShare / weightSum) * targetSeconds);
    const words = Math.round((target / 60) * 145);
    const referenceChapter = chapters[index] ?? undefined;
    return {
      id: section.id,
      index,
      role: section.role,
      title: fillTemplate(section.title, fills),
      referenceChapter,
      purpose: section.purpose,
      intent: ROLE_INTENT[section.role] ?? section.purpose,
      targetSeconds: target,
      targetWords: words,
      spoken: undefined,
      beats: buildBeats(section, fills),
      broll: buildBrollBriefs(section, { ...fills, index }),
      status: "unscripted",
    };
  });

  return {
    version: 1,
    createdAt: new Date().toISOString(),
    topic,
    angle: angle ?? `What ${topic} actually is, and what it takes to get it done.`,
    format,
    formatLabel: template.label,
    formatReference: template.reference,
    target: {
      seconds: targetSeconds,
      words: sections.reduce((sum, section) => sum + section.targetWords, 0),
      sections: sections.length,
      frameRate: spec?.longform?.frameRate ?? 30,
    },
    retention: {
      hookSeconds: 20,
      rehookEverySeconds: 150,
      note: "A new promise or new proof every 2.5 minutes; a pattern interrupt every 8 seconds.",
    },
    channel: spec
      ? {
          name: spec.channel?.name,
          handle: spec.channel?.handle,
          style: spec.longform?.dominantStyle ?? [],
          videoCount: spec.catalogue?.videoCount,
        }
      : undefined,
    sections,
    nextStep:
      "Write `spoken` for every section, then run `creatorize author` to emit the Hypit Source.",
  };
}

function fillTemplate(template, values) {
  return template.replace(/\{(\w+)\}/g, (match, key) => values[key] ?? match);
}

/** "24 minute" / "90 second" - the way a title would say it. */
function formatRuntime(seconds) {
  const minutes = Math.round(seconds / 60);
  if (minutes < 1) return `${Math.round(seconds)} second`;
  return `${minutes} minute`;
}

/**
 * Retention beats. A long-form episode dies in the middle unless each section
 * has a job that is not "more information".
 */
function buildBeats(section, values) {
  const beats = [];
  if (section.role === "hook") {
    beats.push({ at: "0s", kind: "visual", note: `Open on the finished ${values.topic} result, no audio lead-in.` });
    beats.push({ at: "5s", kind: "claim", note: "State the single most surprising number." });
    beats.push({ at: "15s", kind: "promise", note: "Tell the viewer exactly what they will be able to do at the end." });
    return beats;
  }
  beats.push({ at: "0s", kind: "rehook", note: `Open this section with a new promise: "${section.title}".` });
  beats.push({ at: "30%", kind: "proof", note: "Show one concrete artefact from the work so far." });
  beats.push({ at: "70%", kind: "shift", note: "Change the visual register so the section reads as a new movement." });
  beats.push({ at: "95%", kind: "handoff", note: "Land the section on a sentence that pulls into the next one." });
  return beats;
}

/**
 * B-roll briefs. These are what Scenario generates: a picture that proves
 * something, not an illustration of a noun.
 */
function buildBrollBriefs(section, values) {
  const briefs = [];
  const count = section.role === "core" ? 3 : section.role === "hook" ? 2 : 1;
  for (let index = 0; index < count; index += 1) {
    briefs.push({
      id: `${section.id}-b${index + 1}`,
      kind: "still",
      role: index === 0 ? "context" : "proof",
      model: "image",
      brief:
        section.role === "hook"
          ? `A striking frame from the finished ${values.topic} result, high contrast, immediately readable at thumbnail size.`
          : `A concrete visual that proves the claim made in "${section.title}": real detail, real interface, real texture.`,
      negative: "no text, no watermark, no collage, no stock-photo smile",
      aspectRatio: "16:9",
    });
  }
  return briefs;
}

/**
 * Check a plan once the script exists: does the runtime match the words, and
 * does every section still have a job?
 */
export function auditPlan(plan) {
  const findings = [];
  for (const section of plan.sections) {
    if (!section.spoken) {
      findings.push({ level: "error", section: section.id, message: "No spoken text yet." });
      continue;
    }
    const words = section.spoken.trim().split(/\s+/).filter(Boolean).length;
    const seconds = (words / 145) * 60;
    const drift = seconds - section.targetSeconds;
    const ratio = section.targetSeconds > 0 ? seconds / section.targetSeconds : 0;
    if (Math.abs(drift) > Math.max(25, section.targetSeconds * 0.2)) {
      findings.push({
        level: "warn",
        section: section.id,
        message: `${words} words reads as ~${Math.round(seconds)}s against a ${section.targetSeconds}s target (${(ratio * 100).toFixed(0)}%).`,
      });
    }
    if (!section.broll?.length) {
      findings.push({ level: "warn", section: section.id, message: "No B-roll briefed; the section will be a talking head." });
    }
  }
  const unscripted = plan.sections.filter((section) => !section.spoken).length;
  return {
    ok: findings.every((finding) => finding.level !== "error"),
    unscripted,
    findings,
  };
}
