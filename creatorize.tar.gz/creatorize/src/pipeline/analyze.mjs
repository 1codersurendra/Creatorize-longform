/**
 * Channel reconnaissance -> a format spec Creatorize can plan against.
 *
 * Two evidence sources, deliberately kept separate:
 *
 *   catalogue  (always available)  the public channel page: titles, runtimes,
 *                                 upload dates, title formulas, topic clusters.
 *   web        (needs a browser)  REA's passive CDP inspection of the channel
 *                                 and a video page: DOM and accessibility
 *                                 structure, the SPA's route/endpoint graph.
 *
 * The catalogue is the plan's ground truth. REA's evidence explains *why* a
 * channel's catalogue looks the way it does - the tab structure, the metadata
 * the page exposes, the endpoints the front end calls.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { resolveInRepo } from "../config.mjs";
import {
  classifyFormats,
  deriveTitleFormulas,
  deriveTopicClusters,
  enrichTitles,
  fetchChannelPage,
  formatDuration,
  parseChannelPage,
  parseChannelUrl,
  summarizeDurations,
} from "../channel.mjs";

export async function analyzeChannel(url, options = {}) {
  const target = parseChannelUrl(url);
  const html = await fetchChannelPage(target.url);
  const parsed = parseChannelPage(html);
  await enrichTitles(parsed.videos);

  const buckets = classifyFormats(parsed.videos);
  const durations = summarizeDurations(parsed.videos);
  const titles = parsed.videos.map((video) => video.title).filter(Boolean);

  const spec = {
    version: 1,
    generatedAt: new Date().toISOString(),
    source: { url: target.url, handle: target.handle, channelId: parsed.channelId },
    channel: {
      name: parsed.name,
      handle: parsed.handle,
      subscribers: parsed.subscribers,
      description: parsed.description,
    },
    catalogue: {
      videoCount: parsed.videos.length,
      titledCount: titles.length,
      durations,
      formats: {
        short: { count: buckets.short.length, sample: buckets.short.slice(0, 5).map(sample) },
        medium: { count: buckets.medium.length, sample: buckets.medium.slice(0, 5).map(sample) },
        long: { count: buckets.long.length, sample: buckets.long.slice(0, 8).map(sample) },
        livestream: { count: buckets.livestream.length, sample: buckets.livestream.slice(0, 3).map(sample) },
      },
      titleFormulas: deriveTitleFormulas(titles),
      topicClusters: deriveTopicClusters(titles),
      videos: parsed.videos.map((video) => ({
        id: video.id,
        title: video.title,
        duration: video.duration,
        durationSeconds: video.durationSeconds,
        views: video.views,
        published: video.published,
        url: `https://www.youtube.com/watch?v=${video.id}`,
      })),
    },
    longform: {
      // The channel's own long-form band, so a new episode lands inside it.
      band: describeLongformBand(buckets),
      dominantStyle: inferStyle(buckets, titles),
    },
    web: undefined,
  };

  if (options.web === true) {
    const web = await collectWebEvidence(target, { ...options, bundle: options.bundle === true }).catch((error) => ({
      ok: false,
      error: error.message,
      note: "REA web evidence unavailable. The catalogue spec is still complete.",
    }));
    // The evidence record is a research artefact, not configuration. Keeping
    // it out of the spec means the spec stays readable and diffable.
    spec.web = {
      ok: web.ok,
      cdpEndpoint: web.cdpEndpoint,
      targetId: web.targetId,
      evidenceFile: web.ok ? await writeEvidence(web, target) : undefined,
      error: web.error,
      note: web.note,
    };
    if (web.ok) {
      const page = web.page ?? {};
      spec.web.summary = {
        domNodes: page.dom?.total_nodes,
        accessibilityNodes: page.accessibility?.total_nodes,
        networkRequests: page.network?.requests?.length,
        resources: page.resources?.length,
        completeness: page.completeness?.status,
        limitations: page.limitations?.length,
      };
    }
  }

  return spec;
}

/** Write the raw REA evidence beside the spec. */
async function writeEvidence(web, target) {
  const path = resolveInRepo("evidence", `web-${slug(target.handle ?? target.url)}.json`);
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(web, null, 2)}\n`, "utf8");
  return path;
}

function slug(value) {
  return String(value)
    .replace(/[^a-z0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

function sample(video) {
  return { id: video.id, title: video.title, duration: video.duration };
}

/**
 * Where does this channel's long-form actually sit? The channel mixes 20-minute
 * explainers with 3-hour livestreams, and a new episode should target the band
 * the *published* long-form occupies, not the extreme.
 */
function describeLongformBand(buckets) {
  const values = [...buckets.long, ...buckets.livestream]
    .map((video) => video.durationSeconds)
    .filter(Number.isFinite)
    .sort((a, b) => a - b);
  if (values.length === 0) return undefined;
  const at = (q) => values[Math.min(values.length - 1, Math.floor(q * values.length))];
  return {
    count: values.length,
    min: values[0],
    p25: at(0.25),
    median: at(0.5),
    p75: at(0.75),
    max: values[values.length - 1],
    recommendedTargetSeconds: at(0.5),
  };
}

/** Read the production style off the catalogue: flat explainer, 3D, talking head. */
function inferStyle(buckets, titles) {
  const joined = titles.join(" ").toLowerCase();
  const style = [];
  if (/3d|three d|blender|cartoon|stickman|animation/.test(joined)) style.push("3d-animation");
  if (/explainer|flat|vector/.test(joined)) style.push("flat-explainer");
  if (/podcast|interview|conversation/.test(joined)) style.push("podcast");
  if (/documentar/.test(joined)) style.push("documentary");
  if (/short/.test(joined)) style.push("short-form");
  if (buckets.long.length > 0) style.push("long-form");
  return style;
}

/**
 * REA's passive web pass. Creatorize owns a headless Chrome with a loopback
 * debugging port; REA attaches to it and reports what the page actually
 * exposes. Nothing is clicked, navigated or mutated.
 */
async function collectWebEvidence(target, options) {
  const { ReaClient } = await import("../adapters/rea.mjs");
  const { BrowserHarness, findChrome } = await import("../browser.mjs");

  const executable = options.chromePath ?? findChrome();
  if (!executable) {
    throw new Error(
      "No Chrome/Chromium found. Install one or set CREATORIZE_CHROME. " +
        "The catalogue spec is unaffected.",
    );
  }

  const browser = new BrowserHarness({ executablePath: executable });
  const endpoint = await browser.launch();
  try {
    const targetId = await browser.openTarget(target.url);

    // Each capture gets its own REA session. A page inspection and a script
    // bundle analysis each need about 1.5 GB, and a single session that
    // retains both will exhaust the heap on a small host.
    const pageRea = await ReaClient.connect({ command: options.reaCommand, args: options.reaArgs });
    let page;
    try {
      page = await pageRea.inspectPage(endpoint, targetId, {
        allowedOrigins: ["https://www.youtube.com"],
        observationMs: 1500,
        accessibilityText: true,
      });
    } finally {
      await pageRea.close();
    }

    let bundle = { skipped: true, note: "Script-bundle analysis is opt-in. Pass --bundle to run it." };
    if (options.bundle) {
    const bundleRea = await ReaClient.connect({ command: options.reaCommand, args: options.reaArgs });
    try {
      bundle = await bundleRea.analyzeBundle(endpoint, targetId);
    } catch (error) {
      bundle = {
        error: error.message,
        note:
          "The script-bundle capture was skipped. It analyses every script the page loads, " +
          "which needs a larger heap than the default. Raise CREATORIZE_REA_HEAP on a host " +
          "with the memory for it, or leave it out: the page inspection already reports " +
          "the DOM, accessibility tree, resources and network.",
      };
    } finally {
      await bundleRea.close();
    }
    }

    return {
      ok: true,
      cdpEndpoint: endpoint,
      targetId,
      page: page?.normalized ?? page,
      bundle: bundle?.normalized ?? bundle,
    };
  } finally {
    await browser.close();
  }
}

/** Turn a catalogue into the section rhythm a long-form episode should use. */
export function deriveEpisodeRhythm(spec, { targetSeconds } = {}) {
  const band = spec?.longform?.band;
  const duration = targetSeconds ?? band?.recommendedTargetSeconds ?? 1500;
  const videoCount = spec?.catalogue?.formats?.long?.count ?? 1;
  // More published long-form means the channel's audience tolerates more
  // sections; a thin catalogue argues for a tighter spine.
  const sectionCount = Math.max(5, Math.min(9, Math.round(4 + Math.log2(videoCount + 1) * 1.6)));
  const sectionSeconds = Math.round(duration / sectionCount);
  return {
    targetSeconds: duration,
    targetDuration: formatDuration(duration),
    sectionCount,
    sectionSeconds,
    wordsPerMinute: 145,
    estimatedWords: Math.round((duration / 60) * 145),
  };
}

export async function writeSpec(spec, path) {
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, `${JSON.stringify(spec, null, 2)}\n`, "utf8");
  return path;
}
