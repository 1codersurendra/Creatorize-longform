/**
 * Narration: produce the audio the episode's words are read from.
 *
 * Three routes, in descending order of fidelity:
 *
 *   voice   the creator's own recording. One file, or one file per section.
 *   tts     a speech model renders the Script. espeak-ng is used here because
 *           it is free, local and produces real words, so WhisperX can align
 *           it; it is a validation voice, not the final one.
 *   timing  a silent track of the correct length, so the timeline, the
 *           captions and the picture can be validated before a credit is spent.
 *
 * The output is one file per section. Hypit aligns each section's words
 * against its own audio, which is what lets a 25-minute episode be re-cut
 * section by section.
 *
 * The timing route matters most in practice. Knowing that the words overrun
 * section three by 40 seconds is worth knowing before you record 25 minutes
 * of narration.
 */
import { copyFile, mkdir, readdir, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

export class Narrator {
  constructor({ hypit, root, log = console.log }) {
    this.hypit = hypit;
    this.root = root;
    this.log = log;
  }

  layout() {
    return {
      assets: join(this.root, "assets"),
      narration: join(this.root, "assets", "narration"),
    };
  }

  /**
   * Estimate the spoken length of every section. Purely local: Hypit counts
   * pronunciation units and never calls a service.
   */
  async estimate({ sections, language = "en", pace = "normal" } = {}) {
    const results = [];
    for (const section of sections) {
      const text = (section.spoken ?? "").trim();
      if (!text) {
        results.push({ id: section.id, seconds: undefined, words: 0 });
        continue;
      }
      try {
        const result = await this.hypit.run(
          ["estimate", "--text", text, "--language", language, "--pace", pace, "--rounding", "ceil"],
          { cwd: this.root, json: true, timeoutMs: 120000 },
        );
        results.push({
          id: section.id,
          seconds: result.data?.seconds,
          units: result.data?.units,
          rate: result.data?.rate,
          words: text.split(/\s+/).filter(Boolean).length,
        });
      } catch (error) {
        results.push({ id: section.id, seconds: undefined, error: error.message });
      }
    }
    return results;
  }

  /**
   * A silent track per section, of the right length, for a timing proof.
   */
  async createSilentTrack(estimates, { filename = "narration" } = {}) {
    const layout = this.layout();
    await mkdir(layout.narration, { recursive: true });
    let total = 0;
    for (const entry of estimates) {
      const seconds = Math.max(1, Math.ceil(entry.seconds ?? 2));
      total += seconds;
      const target = join(layout.narration, `${entry.id}.m4a`);
      await execFileAsync("ffmpeg", [
        "-y",
        "-f",
        "lavfi",
        "-i",
        "anullsrc=channel_layout=stereo:sample_rate=48000",
        "-t",
        String(seconds),
        "-c:a",
        "aac",
        "-b:a",
        "128k",
        target,
      ]);
    }
    this.log(`silent narration: ${estimates.length} sections, ${total}s -> ${layout.narration}`);
    return { dir: layout.narration, kind: "timing", totalSeconds: total };
  }

  /**
   * Local TTS via espeak-ng. Robotic, but it is real speech with real words,
   * so WhisperX can align it and the captions come out correct. It exists to
   * validate an episode end to end without a credit, not to be the final voice.
   */
  async synthesize({ sections, estimates, language = "en", wordsPerMinute = 165 } = {}) {
    const layout = this.layout();
    const work = join(layout.assets, ".tts");
    await mkdir(work, { recursive: true });
    await mkdir(layout.narration, { recursive: true });

    const voice = language === "en" ? "en-us" : language;
    let total = 0;
    for (const [index, section] of sections.entries()) {
      const text = (section.spoken ?? "").trim();
      if (!text) continue;
      const wav = join(work, `${String(index).padStart(3, "0")}.wav`);
      await execFileAsync("espeak-ng", ["-v", voice, "-s", String(wordsPerMinute), "-w", wav, text]);
      const target = join(layout.narration, `${section.id}.m4a`);
      await execFileAsync("ffmpeg", ["-y", "-i", wav, "-c:a", "aac", "-b:a", "128k", target]);
      total += estimates[index]?.seconds ?? 0;
    }
    this.log(`tts narration: ${sections.length} sections -> ${layout.narration}`);
    return { dir: layout.narration, kind: "tts", totalSeconds: total };
  }

  /**
   * Use the creator's own recording.
   *
   * A directory of per-section files is used as-is. A single file is split
   * proportionally to the estimated section lengths, which is approximate but
   * good enough to place a real performance and far better than blocking.
   */
  async useVoice(voicePath, { estimates = [] } = {}) {
    const layout = this.layout();
    await mkdir(layout.narration, { recursive: true });
    const info = await stat(voicePath);

    if (info.isDirectory()) {
      const files = (await readdir(voicePath)).filter((name) => /\.(m4a|mp3|wav|aac|ogg|flac)$/i.test(name));
      for (const file of files) {
        await copyFile(join(voicePath, file), join(layout.narration, file));
      }
      this.log(`voice: ${files.length} files from ${voicePath}`);
      return { dir: layout.narration, kind: "voice", files: files.length };
    }

    const target = join(layout.narration, "full.m4a");
    await copyFile(voicePath, target);
    this.log(`voice: ${voicePath} -> ${target}`);
    this.log("note: a single recording is not split per section; record one file per section for exact alignment.");
    return { dir: layout.narration, kind: "voice", file: target, split: false };
  }
}
