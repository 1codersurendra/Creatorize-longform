/**
 * Minimal MCP client over stdio (newline-delimited JSON-RPC 2.0).
 *
 * Verified against rea-agents 6.7.0 (`rea mcp`): the server speaks JSONL on
 * stdout, one JSON-RPC message per line, and sends `notifications/initialized`
 * only after the client completes `initialize`.
 *
 * No dependencies on purpose: Creatorize must install cleanly on a creator's
 * machine next to Node, with no supply chain between the tool and the video.
 */
import { spawn } from "node:child_process";

const PROTOCOL_VERSION = "2025-06-18";

export class McpStdioClient {
  #child = null;
  #buffer = "";
  #pending = new Map();
  #nextId = 0;
  #serverInfo = null;
  #tools = null;
  #stderr = "";

  constructor({ command, args = [], cwd, env, clientName = "creatorize", clientVersion = "0.1.0" }) {
    this.command = command;
    this.args = args;
    this.cwd = cwd;
    this.env = env;
    this.clientName = clientName;
    this.clientVersion = clientVersion;
  }

  get serverInfo() {
    return this.#serverInfo;
  }

  get stderr() {
    return this.#stderr;
  }

  async start() {
    if (this.#child) return this;
    this.#child = spawn(this.command, this.args, {
      cwd: this.cwd,
      env: this.env ? { ...process.env, ...this.env } : process.env,
      stdio: ["pipe", "pipe", "pipe"],
    });

    this.#child.stdout.setEncoding("utf8");
    this.#child.stdout.on("data", (chunk) => this.#onData(chunk));

    this.#child.stderr.setEncoding("utf8");
    this.#child.stderr.on("data", (chunk) => {
      this.#stderr = (this.#stderr + chunk).slice(-8000);
    });

    this.#child.on("exit", (code, signal) => {
      const err = new Error(
        `MCP server ${this.command} exited (code=${code} signal=${signal ?? "none"}).` +
          (this.#stderr ? `\n--- stderr ---\n${this.#stderr.slice(-2000)}` : ""),
      );
      for (const [, entry] of this.#pending) entry.reject(err);
      this.#pending.clear();
      this.#child = null;
    });

    const init = await this.#request("initialize", {
      protocolVersion: PROTOCOL_VERSION,
      capabilities: { roots: { listChanged: false }, sampling: {} },
      clientInfo: { name: this.clientName, version: this.clientVersion },
    });
    this.#serverInfo = init?.serverInfo ?? null;
    this.#notify("notifications/initialized", {});
    return this;
  }

  #onData(chunk) {
    this.#buffer += chunk;
    let index;
    while ((index = this.#buffer.indexOf("\n")) >= 0) {
      const line = this.#buffer.slice(0, index).trim();
      this.#buffer = this.#buffer.slice(index + 1);
      if (!line) continue;
      let message;
      try {
        message = JSON.parse(line);
      } catch {
        continue; // not a JSON-RPC frame; the server may emit plain logs
      }
      this.#dispatch(message);
    }
  }

  #dispatch(message) {
    if (message.id !== undefined && this.#pending.has(message.id)) {
      const entry = this.#pending.get(message.id);
      this.#pending.delete(message.id);
      if (message.error) {
        entry.reject(
          new Error(`${entry.method} failed: ${message.error.message ?? JSON.stringify(message.error)}`),
        );
      } else {
        entry.resolve(message.result);
      }
      return;
    }
    if (message.id !== undefined && message.method) {
      // Server-initiated request. We expose no sampling roots, so answer
      // minimally and keep the session alive.
      this.#write({ jsonrpc: "2.0", id: message.id, result: {} });
    }
  }

  #write(payload) {
    if (!this.#child || this.#child.stdin.destroyed) {
      throw new Error("MCP server is not running.");
    }
    this.#child.stdin.write(`${JSON.stringify(payload)}\n`);
  }

  #notify(method, params) {
    this.#write({ jsonrpc: "2.0", method, params });
  }

  #request(method, params, { timeoutMs = 180000 } = {}) {
    const id = ++this.#nextId;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.#pending.delete(id);
        reject(new Error(`MCP request ${method} timed out after ${timeoutMs}ms.`));
      }, timeoutMs);
      this.#pending.set(id, {
        method,
        resolve: (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        reject: (error) => {
          clearTimeout(timer);
          reject(error);
        },
      });
      this.#write({ jsonrpc: "2.0", id, method, params });
    });
  }

  async listTools({ refresh = false } = {}) {
    if (this.#tools && !refresh) return this.#tools;
    const result = await this.#request("tools/list", {});
    this.#tools = result?.tools ?? [];
    return this.#tools;
  }

  async callTool(name, args = {}) {
    const result = await this.#request("tools/call", { name, arguments: args });
    return normalizeToolResult(result);
  }

  async describeTool(name) {
    const tools = await this.listTools();
    return tools.find((tool) => tool.name === name) ?? null;
  }

  async close() {
    if (!this.#child) return;
    const child = this.#child;
    this.#child = null;
    try {
      child.stdin.end();
    } catch {}
    await new Promise((resolve) => {
      const timer = setTimeout(() => {
        try {
          child.kill("SIGKILL");
        } catch {}
        resolve();
      }, 3000);
      child.once("exit", () => {
        clearTimeout(timer);
        resolve();
      });
    });
  }
}

/**
 * MCP tools/call replies are either a plain result object or a content list.
 * Creatorize wants the structured payload when the server offers one, because
 * REA puts its Evidence record in `structuredContent.normalized_result`.
 */
export function normalizeToolResult(result) {
  if (!result) return result;
  if (result.structuredContent) {
    return {
      ...result,
      normalized: result.structuredContent.normalized_result ?? result.structuredContent,
    };
  }
  if (Array.isArray(result.content)) {
    const text = result.content
      .filter((part) => part.type === "text" && typeof part.text === "string")
      .map((part) => part.text)
      .join("\n");
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = undefined;
    }
    if (parsed && typeof parsed === "object") {
      return {
        ...result,
        normalized: parsed.normalized_result ?? parsed,
      };
    }
    return { ...result, text, normalized: undefined };
  }
  return result;
}
