/**
 * Minimal MCP client over streamable HTTP, with OAuth 2.1 device-code support.
 *
 * Verified against the Scenario MCP server (https://mcp.scenario.com/mcp):
 *   - protected resource: https://mcp.scenario.com/mcp
 *   - authorization server: https://mcp.scenario.com
 *   - device endpoint:     https://clerk.scenario.com/oauth/device_authorization
 *   - token endpoint:      https://mcp.scenario.com/oauth/token
 *   - dynamic registration: https://mcp.scenario.com/oauth/register
 *   - PKCE S256 only
 *
 * The server answers POST with either JSON or an SSE stream, so both are parsed.
 */
import { randomBytes, createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

const DEFAULT_BASE = "https://mcp.scenario.com";
const DEFAULT_RESOURCE = "https://mcp.scenario.com/mcp";

export class McpHttpClient {
  constructor({
    endpoint = DEFAULT_RESOURCE,
    accessToken,
    onAuthRequired,
    tokenStorePath,
    fetchImpl = globalThis.fetch,
    timeoutMs = 300000,
  } = {}) {
    this.endpoint = endpoint;
    this.base = endpoint.replace(/\/mcp\/?$/, "");
    this.accessToken = accessToken;
    this.onAuthRequired = onAuthRequired;
    this.tokenStorePath = tokenStorePath;
    this.fetch = fetchImpl;
    this.timeoutMs = timeoutMs;
    this.sessionId = undefined;
    this.#serverInfo = null;
    this.#tools = null;
  }

  #serverInfo;
  #tools;

  get serverInfo() {
    return this.#serverInfo;
  }

  async #headers(extra = {}) {
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json, text/event-stream",
      ...extra,
    };
    if (this.accessToken) headers.Authorization = `Bearer ${this.accessToken}`;
    if (this.sessionId) headers["Mcp-Session-Id"] = this.sessionId;
    return headers;
  }

  async #post(payload, { expectResponse = true } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetch(this.endpoint, {
        method: "POST",
        headers: await this.#headers(),
        body: JSON.stringify(payload),
        signal: controller.signal,
      });
      const session = response.headers.get("mcp-session-id");
      if (session) this.sessionId = session;

      if (response.status === 401) {
        const err = new Error(`MCP server requires authorization (${this.endpoint}).`);
        err.code = "unauthorized";
        throw err;
      }
      if (!response.ok) {
        const body = await response.text().catch(() => "");
        throw new Error(`MCP HTTP ${response.status} ${response.statusText}: ${body.slice(0, 600)}`);
      }
      if (!expectResponse) {
        await response.text().catch(() => "");
        return undefined;
      }

      const contentType = response.headers.get("content-type") ?? "";
      if (contentType.includes("text/event-stream")) {
        return await this.#readSse(response);
      }
      const text = await response.text();
      if (!text.trim()) return undefined;
      try {
        return JSON.parse(text);
      } catch {
        return undefined;
      }
    } finally {
      clearTimeout(timer);
    }
  }

  async #readSse(response) {
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let last = undefined;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let index;
      while ((index = buffer.indexOf("\n\n")) >= 0) {
        const frame = buffer.slice(0, index);
        buffer = buffer.slice(index + 2);
        for (const line of frame.split("\n")) {
          if (!line.startsWith("data:")) continue;
          const payload = line.slice(5).trim();
          if (!payload) continue;
          try {
            last = JSON.parse(payload);
          } catch {
            /* keep the previous frame */
          }
        }
      }
    }
    return last;
  }

  async start() {
    const init = await this.#post({
      jsonrpc: "2.0",
      id: 1,
      method: "initialize",
      params: {
        protocolVersion: "2025-06-18",
        capabilities: {},
        clientInfo: { name: "creatorize", version: "0.1.0" },
      },
    });
    this.#serverInfo = init?.result?.serverInfo ?? init?.serverInfo ?? null;
    await this.#post({
      jsonrpc: "2.0",
      method: "notifications/initialized",
    });
    return this;
  }

  async #request(method, params) {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    const message = await this.#post({ jsonrpc: "2.0", id, method, params });
    if (!message) return undefined;
    if (message.error) {
      throw new Error(`${method} failed: ${message.error.message ?? JSON.stringify(message.error)}`);
    }
    return message.result;
  }

  async listTools({ refresh = false } = {}) {
    if (this.#tools && !refresh) return this.#tools;
    const result = await this.#request("tools/list", {});
    this.#tools = result?.tools ?? [];
    return this.#tools;
  }

  async callTool(name, args = {}) {
    const result = await this.#request("tools/call", { name, arguments: args });
    if (!result) return result;
    let normalized = result.structuredContent?.normalized_result ?? result.structuredContent;
    if (!normalized && Array.isArray(result.content)) {
      const text = result.content
        .filter((part) => part.type === "text" && typeof part.text === "string")
        .map((part) => part.text)
        .join("\n");
      try {
        const parsed = JSON.parse(text);
        normalized = parsed?.normalized_result ?? parsed;
      } catch {
        normalized = text;
      }
    }
    return { ...result, normalized };
  }

  async describeTool(name) {
    const tools = await this.listTools();
    return tools.find((tool) => tool.name === name) ?? null;
  }

  /**
   * Resolve a bearer token. Priority:
   *   1. explicit accessToken
   *   2. token cached at tokenStorePath
   *   3. SCENARIO_API_KEY
   *   4. OAuth authorization code with PKCE against a local callback server
   */
  async authenticate({ force = false } = {}) {
    if (this.accessToken && !force) return this.accessToken;

    if (this.tokenStorePath && !force) {
      const cached = await this.#readTokenStore();
      if (cached?.access_token) {
        this.accessToken = cached.access_token;
        return this.accessToken;
      }
    }

    const apiKey = process.env.SCENARIO_API_KEY;
    if (apiKey && !force) {
      this.accessToken = apiKey;
      return this.accessToken;
    }

    const token = await this.#authorizationCodeFlow();
    this.accessToken = token.access_token;
    if (this.tokenStorePath) await this.#writeTokenStore(token);
    return this.accessToken;
  }

  async #readTokenStore() {
    try {
      return JSON.parse(await readFile(this.tokenStorePath, "utf8"));
    } catch {
      return undefined;
    }
  }

  async #writeTokenStore(token) {
    await mkdir(dirname(this.tokenStorePath), { recursive: true });
    await writeFile(this.tokenStorePath, `${JSON.stringify(token, null, 2)}\n`, "utf8");
  }

  /**
   * OAuth authorization code with PKCE, against a loopback callback.
   *
   * Scenario's authorization server advertises the device-code grant, but its
   * dynamic client registration only issues `authorization_code` and
   * `refresh_token` clients, so a device request comes back `invalid_grant`.
   * The authorization code flow is the one that actually works, and PKCE
   * S256 is the only challenge method the server accepts.
   */
  async #authorizationCodeFlow() {
    const client = await this.#registerClient();
    const verifier = randomBytes(48).toString("base64url");
    const challenge = createHash("sha256").update(verifier).digest("base64url");

    // The callback server has to be listening before the browser is sent
    // anywhere, but the code cannot be awaited until the user has approved.
    const redirect = await this.#startRedirectServer();

    const authorizeUrl = new URL(`${this.base}/oauth/authorize`);
    authorizeUrl.searchParams.set("response_type", "code");
    authorizeUrl.searchParams.set("client_id", client.client_id);
    authorizeUrl.searchParams.set("redirect_uri", redirect.redirectUri);
    authorizeUrl.searchParams.set("scope", "openid profile email");
    authorizeUrl.searchParams.set("code_challenge", challenge);
    authorizeUrl.searchParams.set("code_challenge_method", "S256");
    authorizeUrl.searchParams.set("resource", DEFAULT_RESOURCE);

    const onAuthRequired = this.onAuthRequired;
    if (typeof onAuthRequired === "function") {
      await onAuthRequired({ authorizationUrl: authorizeUrl.toString() });
    } else {
      console.error(
        `\nScenario sign-in required.\nOpen this URL in a browser and approve access:\n\n${authorizeUrl}\n\n` +
          `Waiting for the redirect on ${redirect.redirectUri}...\n`,
      );
    }

    try {
      const code = await redirect.code;
      const response = await this.fetch(`${this.base}/oauth/token`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          client_id: client.client_id,
          redirect_uri: redirect.redirectUri,
          code_verifier: verifier,
          resource: DEFAULT_RESOURCE,
        }),
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(
          `OAuth token exchange failed: ${body.error_description ?? body.error ?? response.status}`,
        );
      }
      return response.json();
    } finally {
      await redirect.close();
    }
  }

  /** A one-shot loopback server that waits for the authorization redirect. */
  async #startRedirectServer({ timeoutMs = 300000 } = {}) {
    const { createServer } = await import("node:http");
    let resolveCode;
    let rejectCode;
    const codePromise = new Promise((resolve, reject) => {
      resolveCode = resolve;
      rejectCode = reject;
    });
    // Nothing may await the code until the URL has been shown, but the promise
    // must not surface an unhandled rejection while it waits.
    codePromise.catch(() => {});

    const server = createServer((request, response) => {
      const url = new URL(request.url, "http://127.0.0.1");
      const code = url.searchParams.get("code");
      const error = url.searchParams.get("error");
      response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      if (code) {
        response.end(
          "<html><body style='font-family:system-ui;padding:40px'><h2>Creatorize is connected.</h2>" +
            "<p>You can close this tab and return to the terminal.</p></body></html>",
        );
        resolveCode(code);
      } else {
        response.end(
          "<html><body style='font-family:system-ui;padding:40px'><h2>Sign-in failed.</h2>" +
            `<p>${error ?? "No authorization code was returned."}</p></body></html>`,
        );
        rejectCode(new Error(error ?? "No authorization code was returned."));
      }
    });

    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", resolve);
    });
    const { port } = server.address();
    const redirectUri = `http://127.0.0.1:${port}/callback`;

    const timer = setTimeout(() => {
      rejectCode(new Error("Timed out waiting for the OAuth redirect."));
    }, timeoutMs);

    return {
      code: codePromise.finally(() => clearTimeout(timer)),
      redirectUri,
      close: () =>
        new Promise((resolve) => {
          server.close(() => resolve());
        }),
    };
  }

  async #registerClient() {
    const response = await this.fetch(`${this.base}/oauth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        client_name: "Creatorize",
        redirect_uris: ["http://127.0.0.1/callback"],
        grant_types: ["authorization_code", "refresh_token"],
        response_types: ["code"],
        token_endpoint_auth_method: "none",
      }),
    });
    if (!response.ok) {
      throw new Error(`OAuth client registration failed (${response.status}).`);
    }
    return response.json();
  }
}
