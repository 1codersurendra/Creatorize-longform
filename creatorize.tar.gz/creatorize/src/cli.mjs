/**
 * Creatorize CLI.
 *
 * A long-form faceless YouTube pipeline that chains three tools:
 *
 *   REA     read the reference: the channel's page, its structure, or a
 *           shipped app's behaviour
 *   Scenario generate the material: stills that prove a claim, thumbnails
 *   Hypit  author and render: script, captions, B-roll, timeline, film
 */
import { existsSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { loadConfig, REPO_ROOT, resolveInRepo, TOKEN_STORE_PATH } from "./config.mjs";
import { ReaClient } from "./adapters/rea.mjs";
import { HypitClient } from "./adapters/hypit.mjs";
import { AssetGenerator, generatePlaceholderBroll } from "./pipeline/assets.mjs";
import { analyzeChannel, deriveEpisodeRhythm, writeSpec } from "./pipeline/analyze.mjs";
import { applyScript, readPlan, writeProject, projectLayout, writeReuseRun, writeAlignmentRun, readBuildOutputs } from "./pipeline/author.mjs";
import { buildPlan, listTemplates, auditPlan } from "./pipeline/plan.mjs";
import { Builder, extractBuildId } from "./pipeline/build.mjs";
import { Narrator } from "./pipeline/narrate.mjs";
import { installProjectDependencies } from "./pipeline/deps.mjs";
import { fetchChapters, formatDuration } from "./channel.mjs";
import { findChrome } from "./browser.mjs";

const args = process.argv.slice(2);
const command = args[0];

const flags = {};
const positional = [];
for (let index = 1; index < args.length; index += 1) {
  const token = args[index];
  if (!token.startsWith("--")) {
    positional.push(token);
    continue;
  }
  const key = token.slice(2);
  const next = args[index + 1];
  if (next === undefined || next.startsWith("--")) {
    flags[key] = true;
  } else {
    flags[key] = next;
    index += 1;
  }
}

const log = (...args) => console.log(...args);
const warn = (...args) => console.warn(...args);

try {
  await run();
} catch (error) {
  console.error(`\ncreatorize: ${error.message}`);
  if (flags.debug) console.error(error.stack);
  process.exitCode = 1;
}

async function run() {
  const config = await loadConfig();
  switch (command) {
    case "doctor":
      return doctor(config);
    case "analyze":
      return analyze(config);
    case "chapters":
      return chapters();
    case "plan":
      return plan(config);
    case "author":
      return author(config);
    case "assets":
      return assets(config);
    case "narrate":
      return narrate(config);
    case "align":
      return align(config);
    case "build":
      return build(config);
    case "recon":
      return recon(config);
    case "auth":
      return auth(config);
    case "init":
      return init(config);
    case "formats":
      return listTemplates().forEach((template) =>
        log(`  ${template.key.padEnd(12)} ${template.sections} sections  ${template.label}`),
      );
    case undefined:
    case "help":
    case "--help":
      return help();
    default:
      throw new Error(`Unknown command "${command}". Run \`creatorize help\`.`);
  }
}

function help() {
  log(`creatorize - long-form faceless YouTube production

  creatorize doctor                      check every dependency and credential
  creatorize analyze [url] [--web]       reverse-engineer a channel into a format spec
  creatorize chapters <videoId...>       read a video's own chapter list
  creatorize plan <topic>                build an episode plan from the channel spec
  creatorize author                      write the Hypit project from a plan
  creatorize narrate                     produce the narration (voice / tts / timing track)
  creatorize align                       transcribe the narration into word timings only
  creatorize assets                      generate B-roll and thumbnail via Scenario
  creatorize build                       check, build and export with Hypit
  creatorize recon <path>                reverse-engineer a local app with REA
  creatorize auth scenario               sign in to Scenario
  creatorize init [dir]                  scaffold a project directory
  creatorize formats                     list the long-form section templates

Options
  --config <path>     extra config file
  --spec <path>       channel spec to plan against (default config/channels/g-russ.json)
  --project <dir>     project directory
  --plan <path>       plan file
  --script <path>     script file (JSON: {"sections":{"<id>":"text"}})
  --format <name>     tutorial | documentary
  --seconds <n>       target runtime
  --output <path>     where to write the rendered video
  --reuse <buildId>   re-render the picture, reusing an earlier build's narration
  --align             with --reuse, only the missing alignments are produced
  --web               also collect REA browser evidence
  --bundle            with --web, also analyse the page's script graph (heap hungry)
  --json              machine-readable output
`);
}

async function doctor(config) {
  const report = {
    node: { ok: true, value: process.version },
    tools: {},
    credentials: {},
    paths: {},
  };

  report.tools.hypit = await probe(
    config.tools.hypit.command,
    [config.tools.hypit.command, "version"],
    "the hypit CLI is not on PATH",
  );
  report.tools.rea = await probe(
    config.tools.rea.command,
    [config.tools.rea.command, "--version"],
    "the rea CLI is not on PATH (npm i -g rea-agents)",
  );
  const chrome = config.tools.chrome.path ?? findChrome();
  report.tools.chrome = {
    ok: Boolean(chrome),
    value: chrome ?? "not found",
    note: chrome
      ? undefined
      : "REA's web pass needs a Chrome with a remote debugging port. Set CREATORIZE_CHROME.",
  };
  report.tools.ffmpeg = await probe("ffmpeg", ["ffmpeg", "-version"], "ffmpeg is not on PATH");

  report.credentials.scenario = {
    ok: Boolean(process.env.SCENARIO_API_KEY),
    value: process.env.SCENARIO_API_KEY ? "SCENARIO_API_KEY set" : "not set",
    note: process.env.SCENARIO_API_KEY
      ? undefined
      : "Scenario is optional. Run `creatorize auth scenario` to sign in, or set SCENARIO_API_KEY.",
  };

  report.paths.workspace = { ok: true, value: REPO_ROOT };
  report.paths.spec = {
    ok: existsSync(resolveInRepo(config.channel.spec)),
    value: config.channel.spec,
  };

  if (flags.json) {
    log(JSON.stringify(report, null, 2));
    return report;
  }

  log("\nCreatorize doctor\n");
  for (const [group, entries] of Object.entries(report)) {
    if (group === "node") continue;
    log(`  ${group}`);
    for (const [name, entry] of Object.entries(entries)) {
      const mark = entry.ok ? "ok  " : "WARN";
      log(`    [${mark}] ${name.padEnd(12)} ${entry.value ?? ""}${entry.note ? `  - ${entry.note}` : ""}`);
    }
  }
  log("");
  return report;
}

async function probe(command, argv, note) {
  try {
    const { execFile } = await import("node:child_process");
    const { promisify } = await import("node:util");
    const { stdout } = await promisify(execFile)(argv[0], argv.slice(1), { timeout: 120000 });
    return { ok: true, value: stdout.split("\n")[0].trim() };
  } catch (error) {
    return { ok: false, value: "unavailable", note };
  }
}

async function analyze(config) {
  const url = positional[0] ?? config.channel.url;
  const spec = await analyzeChannel(url, {
    web: flags.web === true,
    bundle: flags.bundle === true,
    chromePath: config.tools.chrome.path,
    reaCommand: config.tools.rea.command,
    reaArgs: config.tools.rea.args,
  });

  const target = flags.spec ?? config.channel.spec;
  const path = resolveInRepo(target);
  await writeSpec(spec, path);
  const rhythm = deriveEpisodeRhythm(spec);

  if (flags.json) {
    log(JSON.stringify({ spec, rhythm, path }, null, 2));
    return spec;
  }

  log(`\nChannel      ${spec.channel.name ?? "unknown"} ${spec.channel.handle ?? ""}`);
  log(`URL          ${spec.source.url}`);
  log(`Videos       ${spec.catalogue.videoCount} (${spec.catalogue.titledCount} titled)`);
  if (spec.catalogue.durations) {
    const d = spec.catalogue.durations;
    log(`Runtime      median ${formatDuration(d.median)}  p25 ${formatDuration(d.p25)}  p75 ${formatDuration(d.p75)}  max ${formatDuration(d.max)}`);
  }
  log(
    `Formats      short ${spec.catalogue.formats.short.count}  medium ${spec.catalogue.formats.medium.count}  long ${spec.catalogue.formats.long.count}  live ${spec.catalogue.formats.livestream.count}`,
  );
  if (spec.longform.band) {
    log(`Long-form    ${spec.longform.band.count} episodes, target ${formatDuration(spec.longform.band.recommendedTargetSeconds)}`);
  }
  if (spec.longform.dominantStyle?.length) {
    log(`Style        ${spec.longform.dominantStyle.join(", ")}`);
  }
  if (spec.catalogue.titleFormulas.length) {
    log("\nRecurring title shapes");
    for (const formula of spec.catalogue.titleFormulas.slice(0, 6)) {
      log(`  ${String(formula.count).padStart(3)}x  ${formula.formula}`);
    }
  }
  if (spec.catalogue.topicClusters.length) {
    log("\nRecurring subjects");
    log(`  ${spec.catalogue.topicClusters.slice(0, 12).map((c) => `${c.term}(${c.count})`).join("  ")}`);
  }
  log(`\nSpec written to ${path}`);
  log(`Next: creatorize plan "your topic"\n`);
  return spec;
}

async function chapters() {
  if (positional.length === 0) throw new Error("Pass at least one video id or URL.");
  for (const target of positional) {
    const id = extractVideoId(target);
    const found = await fetchChapters(id);
    log(`\n${target}`);
    if (found.length === 0) {
      log("  (no chapter list published)");
      continue;
    }
    for (const chapter of found) log(`  ${String(chapter.at).padStart(8)}  ${chapter.title}`);
  }
}

function extractVideoId(value) {
  const direct = value.match(/([\w-]{11})/);
  if (direct) return direct[1];
  throw new Error(`Could not read a video id from "${value}".`);
}

async function plan(config) {
  const topic = positional.join(" ");
  if (!topic) throw new Error('Pass a topic: creatorize plan "how to build a faceless channel"');

  const specPath = resolveInRepo(flags.spec ?? config.channel.spec);
  let spec;
  if (existsSync(specPath)) spec = JSON.parse(await readFile(specPath, "utf8"));
  else warn(`No spec at ${specPath}. Run \`creatorize analyze\` first; planning without one.`);

  const chaptersArg = flags.chapters
    ? await fetchChapters(extractVideoId(String(flags.chapters)))
    : [];

  const built = buildPlan({
    topic,
    format: flags.format ?? "tutorial",
    angle: flags.angle,
    seconds: flags.seconds ? Number(flags.seconds) : undefined,
    spec,
    tool: flags.tool ?? "the tool",
    style: flags.style ?? "house",
    chapters: chaptersArg.map((chapter) => chapter.title),
  });

  const out = flags.out ?? resolveInRepo("projects", "_plans", `${slug(topic)}.json`);
  await mkdir(resolve(out, ".."), { recursive: true });
  await writeFile(out, `${JSON.stringify(built, null, 2)}\n`, "utf8");

  if (flags.json) {
    log(JSON.stringify(built, null, 2));
    return built;
  }

  log(`\n${built.topic}  (${built.formatLabel})`);
  log(`${built.formatReference}\n`);
  for (const section of built.sections) {
    log(
      `  ${String(section.index + 1).padStart(2)}. ${section.title.padEnd(38)} ${String(section.targetSeconds).padStart(4)}s  ${section.targetWords}w`,
    );
    if (section.referenceChapter) log(`      ↳ channel's own chapter: "${section.referenceChapter}"`);
  }
  log(`\nTarget: ${formatDuration(built.target.seconds)}  ·  ${built.target.words} words  ·  ${built.target.sections} sections`);
  log(`Plan written to ${out}`);
  log(`Next: write the script, then creatorize author --plan ${out}\n`);
  return built;
}

async function author(config) {
  const planPath = flags.plan ?? resolveInRepo("projects", "_plans", `${slug("default")}.json`);
  if (!existsSync(planPath)) throw new Error(`No plan at ${planPath}. Run \`creatorize plan\` first.`);
  const planData = JSON.parse(await readFile(planPath, "utf8"));

  let current = planData;
  if (flags.script) {
    const script = JSON.parse(await readFile(resolve(flags.script), "utf8"));
    const applied = applyScript(planData, script);
    current = applied.plan;
    log(`Applied script to ${applied.applied}/${current.sections.length} sections.`);
  }

  const root = resolve(flags.project ?? resolveInRepo("projects", slug(current.topic)));
  const result = await writeProject(root, current, {
    longform: {
      width: config.longform.width,
      height: config.longform.height,
      frameRate: config.longform.frameRate,
      language: config.longform.language,
    },
    narrationDir: flags.narration ?? "../assets/narration",
  });

  if (flags.install !== false) {
    const installed = await installProjectDependencies(root, { log });
    if (installed.added.length === 0) log("  (all project dependencies already present)");
  }

  const audit = auditPlan(current);
  log(`\nProject written to ${root}`);
  log(`  ${result.layout.authors}/episode.svml`);
  log(`  ${result.layout.recipes}/longform.svs`);
  log(`  ${result.layout.runs}/episode.svrun`);
  if (audit.findings.length) {
    log("\nPlan audit");
    for (const finding of audit.findings) {
      log(`  [${finding.level}] ${finding.section}: ${finding.message}`);
    }
  }
  log(`\nNext: add the narration to ${result.layout.assets}/narration.m4a, then creatorize build --project ${root}\n`);
  return result;
}

async function narrate(config) {
  const root = resolve(flags.project ?? resolveInRepo("projects"));
  const layout = projectLayout(root);
  if (!existsSync(layout.state)) throw new Error(`No project at ${root}. Run \`creatorize author\` first.`);

  const state = JSON.parse(await readFile(layout.state, "utf8"));
  const plan = state.plan;
  const hypit = new HypitClient({ command: config.tools.hypit.command });
  const narrator = new Narrator({ hypit, root, log });

  const estimates = await narrator.estimate({
    sections: plan.sections,
    language: config.longform.language ?? "en",
  });
  const total = estimates.reduce((sum, entry) => sum + (entry.seconds ?? 0), 0);

  log("\nSection timing (hypit estimate, local, no credits)");
  for (const [index, entry] of estimates.entries()) {
    const section = plan.sections[index];
    const target = section?.targetSeconds ?? 0;
    const drift = entry.seconds !== undefined ? entry.seconds - target : undefined;
    log(
      `  ${String(section?.id ?? entry.id).padEnd(14)} ${String(entry.seconds ?? "?").padStart(6)}s  target ${String(target).padStart(5)}s` +
        `  ${drift === undefined ? "" : `drift ${drift >= 0 ? "+" : ""}${Math.round(drift)}s`}`,
    );
  }
  log(`  ${"total".padEnd(14)} ${Math.round(total)}s  (plan target ${plan.target.seconds}s)`);

  let result;
  if (flags.voice) {
    result = await narrator.useVoice(resolve(flags.voice), { estimates });
  } else if (flags.tts === "espeak" || flags.tts === true) {
    result = await narrator.synthesize({
      sections: plan.sections,
      estimates,
      language: config.longform.language ?? "en",
    });
  } else {
    result = await narrator.createSilentTrack(estimates);
  }

  log(`\nNarration: ${result.kind} -> ${result.dir}`);
  log(`Next: creatorize build --project ${root}\n`);
  return { estimates, total, result };
}

async function assets(config) {
  const root = resolve(flags.project ?? resolveInRepo("projects"));
  const layout = projectLayout(root);
  if (!existsSync(layout.state)) throw new Error(`No project at ${root}. Run \`creatorize author\` first.`);

  const state = JSON.parse(await readFile(layout.state, "utf8"));
  const brollDir = join(layout.assets, "broll");
  let results;

  if (flags.placeholder) {
    results = await generatePlaceholderBroll(state.plan, { assetsDir: brollDir });
  } else {
    const generator = await AssetGenerator.connect({
      endpoint: config.tools.scenario.endpoint,
      tokenStorePath: TOKEN_STORE_PATH,
      dryRun: flags["dry-run"] === true,
    });
    results = await generator.generatePlanBroll(state.plan, { assetsDir: brollDir });
  }

  for (const result of results) {
    log(`  [${result.status}] ${result.id}${result.path ? ` -> ${result.path}` : result.error ? ` (${result.error})` : ""}`);
  }

  if (flags.thumbnail && !flags.placeholder) {
    const generator = await AssetGenerator.connect({
      endpoint: config.tools.scenario.endpoint,
      tokenStorePath: TOKEN_STORE_PATH,
    });
    const thumb = await generator.generateThumbnail({
      topic: state.plan.topic,
      title: state.plan.title,
      assetsDir: layout.assets,
    });
    log(`  [${thumb.status}] thumbnail${thumb.path ? ` -> ${thumb.path}` : ""}`);
  }

  const manifest = join(brollDir, "broll.json");
  await mkdir(brollDir, { recursive: true });
  await writeFile(manifest, `${JSON.stringify(results, null, 2)}\n`, "utf8");
  log(`\nB-roll manifest written to ${manifest}`);
  log(`Next: creatorize author --plan <plan> --project ${root}   (re-author to wire the clips in)`);
  return results;
}

/**
 * Transcribe without rendering.
 *
 * A long-form episode needs the word timings before it needs the picture, and
 * the two have very different memory profiles. Splitting them lets the
 * transcription service be stopped before the rasteriser starts, which is the
 * difference between a render that fits and one that does not.
 */
async function align(config) {
  const root = resolve(flags.project ?? resolveInRepo("projects"));
  const layout = projectLayout(root);
  if (!existsSync(layout.state)) throw new Error(`No project at ${root}. Run \`creatorize author\` first.`);

  const state = JSON.parse(await readFile(layout.state, "utf8"));
  const hypit = new HypitClient({ command: config.tools.hypit.command });
  const builder = new Builder({ hypit, root, log });

  const sections = state.plan.sections;
  const run = await writeAlignmentRun(root, sections);
  log(`Alignment Run written: ${run.path}`);
  log(`Targeting ${run.targets.length} alignment outputs.`);

  const built = await hypit.build(run.path, { cwd: layout.root, follow: true });
  const buildId = extractBuildId(built);
  if (!buildId) {
    warn("The alignment build did not report a build id.");
    return { ok: false, raw: built.stdout };
  }
  log(`\nAlignment build ${buildId} complete.`);
  log(`Next: stop the transcription service, then creatorize build --project ${root} --reuse ${buildId}`);
  return { ok: true, buildId, targets: run.targets };
}

async function build(config) {
  const root = resolve(flags.project ?? resolveInRepo("projects"));
  const layout = projectLayout(root);
  if (!existsSync(layout.state)) throw new Error(`No project at ${root}. Run \`creatorize author\` first.`);

  const hypit = new HypitClient({ command: config.tools.hypit.command });
  const builder = new Builder({ hypit, root, log });

  // --reuse <buildId> re-renders the picture from an earlier build's
  // narration and word timing, without asking the transcription service again.
  if (flags.reuse) {
    const state = JSON.parse(await readFile(layout.state, "utf8"));
    const available = await readBuildOutputs(root, String(flags.reuse));
    const reuse = await writeReuseRun(root, String(flags.reuse), state.plan.sections, { availableOutputs: available });
    log(`Reuse Run written: ${reuse.path}`);
    log(`Satisfying ${reuse.records.length} outputs from build ${flags.reuse}.`);
    if (reuse.missing.length > 0) {
      log(`${reuse.missing.length} output(s) were never produced by that build and will be made again:`);
      for (const output of reuse.missing.slice(0, 6)) log(`  ${output}`);
    }
    const result = await builder.run({ runFile: "episode-reuse.svrun", output: flags.output ?? "episode.mp4" });
    if (!result.ok) {
      warn(`Build did not complete: ${result.reason ?? result.error}`);
      return result;
    }
    log(`\nBuild ${result.buildId} complete.`);
    const exported = result.exported;
    if (exported?.ok === false) warn(`Export failed: ${exported.error}`);
    else log(`Output: ${exported?.data?.path ?? exported?.stdout ?? "see hypit get"}`);
    return result;
  }

  if (flags.check) {
    const result = await builder.check();
    log(result.stdout);
    return result;
  }
  if (flags.plan) {
    const result = await builder.plan();
    log(result.stdout);
    return result;
  }

  const result = await builder.run({ output: flags.output ?? "episode.mp4" });
  if (!result.ok) {
    warn(`Build did not complete: ${result.reason ?? result.error}`);
    return result;
  }
  log(`\nBuild ${result.buildId} complete.`);
  const exported = result.exported;
  if (exported?.ok === false) {
    warn(`Export failed: ${exported.error}`);
  } else {
    log(`Output: ${exported?.data?.path ?? exported?.stdout ?? "see hypit get"}`);
  }
  return result;
}

/**
 * REA against a local artifact. This is the "see a feature, understand it"
 * loop: point it at a shipped app (the Creatorize desktop build, an ASAR, a
 * binary) and it returns evidence about how the app works.
 *
 * The right REA tool depends on the artifact. A JavaScript or Electron app is
 * analysed statically and needs no decompiler; a native binary needs Ghidra,
 * Hopper or IDA. The command picks the tool that can actually answer, and
 * says so plainly when the tool it needs is not installed.
 */
async function recon(config) {
  const target = positional[0];
  if (!target) throw new Error("Pass a path: creatorize recon /path/to/app");

  const resolved = resolve(target);
  const kind = await detectArtifactKind(resolved);

  const rea = await ReaClient.connect({
    command: config.tools.rea.command,
    args: config.tools.rea.args,
  });
  try {
    const capabilities = await rea.capabilities();
    log(`REA ${capabilities.server?.name ?? ""} ${capabilities.server?.version ?? ""} - ${capabilities.total} tools`);

    let report;
    if (kind === "javascript") {
      log(`Artifact: JavaScript / Electron application - static analysis, no decompiler needed.`);
      const application = await rea.call("analyze_javascript_application", { input_path: resolved });
      report = {
        target: resolved,
        kind,
        application: application?.normalized ?? application,
      };
    } else {
      log(`Artifact: ${kind} - native analysis needs Ghidra, Hopper or IDA.`);
      const opened = await rea.openBinary(resolved);
      const overview = await rea.overview().catch((error) => ({ error: error.message }));
      const strings = await rea.strings().catch((error) => ({ error: error.message }));
      const procedures = await rea.procedures().catch((error) => ({ error: error.message }));
      report = {
        target: resolved,
        kind,
        opened: opened?.normalized ?? opened,
        overview: overview?.normalized ?? overview,
        strings: strings?.normalized ?? strings,
        procedures: procedures?.normalized ?? procedures,
      };
    }

    const out = flags.out ?? resolveInRepo("evidence", `recon-${slug(target)}.json`);
    await mkdir(resolve(out, ".."), { recursive: true });
    await writeFile(out, `${JSON.stringify(report, null, 2)}\n`, "utf8");
    log(`\nEvidence written to ${out}`);
    if (flags.json) log(JSON.stringify(report, null, 2));
    else summariseRecon(report);
    return report;
  } finally {
    await rea.close();
  }
}

/** What kind of thing is this? It decides which REA tool can answer. */
async function detectArtifactKind(path) {
  const { stat, readdir, readFile } = await import("node:fs/promises");
  const info = await stat(path).catch(() => undefined);
  if (!info) return "missing";
  if (info.isDirectory()) {
    const entries = await readdir(path).catch(() => []);
    if (entries.includes("package.json")) {
      const manifest = JSON.parse(await readFile(`${path}/package.json`, "utf8").catch(() => "{}"));
      return manifest.build?.asar || manifest.main?.endsWith(".js") ? "javascript" : "javascript";
    }
    if (entries.some((name) => name.endsWith(".asar"))) return "javascript";
    if (entries.some((name) => name.endsWith(".app") || name === "Contents")) return "native";
    return "directory";
  }
  if (path.endsWith(".asar")) return "javascript";
  if (path.endsWith(".apk")) return "android";
  if (path.endsWith(".js") || path.endsWith(".mjs")) return "javascript";
  if (path.endsWith(".exe") || path.endsWith(".dll") || path.endsWith(".so") || path.endsWith(".dylib")) {
    return "native";
  }
  return "native";
}

function summariseRecon(report) {
  if (report.kind === "javascript") {
    const app = report.application?.normalized_result ?? report.application;
    const graph = app?.modules ?? app?.application ?? {};
    const modules = graph.modules ?? app?.modules;
    log(`  modules: ${Array.isArray(modules) ? modules.length : "see file"}`);
    if (app?.limitations) log(`  limitations: ${JSON.stringify(app.limitations).slice(0, 200)}`);
    return;
  }
  for (const key of ["overview", "strings", "procedures"]) {
    const value = report[key];
    if (value?.error) {
      log(`  ${key}: unavailable - ${value.error.message ?? value.error}`);
    } else {
      log(`  ${key}: captured`);
    }
  }
}

async function auth() {
  const { ScenarioClient } = await import("./adapters/scenario.mjs");
  const client = new ScenarioClient({
    tokenStorePath: TOKEN_STORE_PATH,
    onAuthRequired: ({ authorizationUrl }) => {
      log("\nOpen this URL in a browser and approve access for Creatorize:\n");
      log(authorizationUrl);
      log("\nWaiting for the redirect...\n");
    },
  });
  const token = await client.mcp.authenticate();
  log(`Scenario authenticated. Token stored at ${TOKEN_STORE_PATH}`);
  log("The tool will use it automatically. You can also export it as SCENARIO_API_KEY.");
  return token;
}

async function init() {
  const root = resolve(positional[0] ?? "creatorize-project");
  const layout = projectLayout(root);
  await Promise.all([
    mkdir(layout.authors, { recursive: true }),
    mkdir(layout.recipes, { recursive: true }),
    mkdir(layout.runs, { recursive: true }),
    mkdir(layout.assets, { recursive: true }),
  ]);
  await writeFile(
    join(root, "package.json"),
    `${JSON.stringify({ name: "creatorize-episode", version: "0.0.0", private: true, type: "module", hypit: { project: true } }, null, 2)}\n`,
    "utf8",
  );
  await writeFile(join(layout.assets, ".gitkeep"), "");
  log(`Scaffolded ${root}`);
  if (flags.install !== false) {
    await installProjectDependencies(root, { log });
  }
  return root;
}

function slug(value) {
  return String(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}
