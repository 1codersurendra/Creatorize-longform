/**
 * A loopback Chrome instance for REA's CDP tools.
 *
 * REA refuses any endpoint that is not a literal loopback CDP address, and it
 * never drives a browser for the caller: it attaches to one. So Creatorize owns
 * the browser lifecycle — launch Chrome headless with a remote debugging port,
 * read the port Chrome publishes in `DevToolsActivePort`, then hand the
 * endpoint to REA.
 */
import { spawn } from "node:child_process";
import { existsSync, readdirSync } from "node:fs";
import { readFile, mkdtemp, rm } from "node:fs/promises";
import { homedir, tmpdir } from "node:os";
import { join } from "node:path";

const CANDIDATE_PATHS = [
  process.env.CREATORIZE_CHROME,
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser",
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
  "/opt/google/chrome/chrome",
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Chromium.app/Contents/MacOS/Chromium",
  "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
].filter(Boolean);

export function findChrome() {
  for (const candidate of CANDIDATE_PATHS) {
    if (existsSync(candidate)) return candidate;
  }
  // Playwright's cache holds a Chromium build that works perfectly well as a
  // CDP host, and it is what `rea setup` / `hypit capture install-browser`
  // already put on disk.
  for (const root of playwrightRoots()) {
    for (const relative of [
      "chrome-linux64/chrome",
      "chrome-linux/chrome",
      "chrome-mac/Chromium.app/Contents/MacOS/Chromium",
      "chrome-win/chrome.exe",
    ]) {
      const candidate = join(root, relative);
      if (existsSync(candidate)) return candidate;
    }
  }
  return undefined;
}

function playwrightRoots() {
  const roots = [];
  const bases = [process.env.PLAYWRIGHT_BROWSERS_PATH, join(homedir(), ".cache", "ms-playwright")].filter(Boolean);
  for (const base of bases) {
    if (!existsSync(base)) continue;
    for (const entry of readdirSync(base, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      if (!/^chromium/.test(entry.name)) continue;
      roots.push(join(base, entry.name));
    }
  }
  return roots;
}

export class BrowserHarness {
  constructor({ executablePath = findChrome(), headless = true } = {}) {
    this.executablePath = executablePath;
    this.headless = headless;
    this.child = undefined;
    this.profileDir = undefined;
    this.cdpEndpoint = undefined;
  }

  get available() {
    return Boolean(this.executablePath);
  }

  async launch() {
    if (!this.executablePath) {
      throw new Error(
        "No Chrome/Chromium executable found. Install one, or set CREATORIZE_CHROME to its path. " +
          "REA requires a browser with a remote debugging port.",
      );
    }
    this.profileDir = await mkdtemp(join(tmpdir(), "creatorize-chrome-"));
    const args = [
      "--remote-debugging-port=0",
      `--user-data-dir=${this.profileDir}`,
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-gpu",
      "--disable-dev-shm-usage",
      "--no-sandbox",
      "--disable-extensions",
      "--disable-background-networking",
      "about:blank",
    ];
    if (this.headless) args.unshift("--headless=new");

    this.child = spawn(this.executablePath, args, { stdio: ["ignore", "pipe", "pipe"] });
    this.child.stdout.resume();
    this.child.stderr.resume();

    const port = await this.#waitForPort();
    this.cdpEndpoint = `http://127.0.0.1:${port}`;
    return this.cdpEndpoint;
  }

  async #waitForPort({ timeoutMs = 45000 } = {}) {
    const portFile = join(this.profileDir, "DevToolsActivePort");
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const content = await readFile(portFile, "utf8");
        const port = content.split("\n")[0]?.trim();
        if (port) return port;
      } catch {
        /* not written yet */
      }
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
    throw new Error("Chrome did not publish a DevTools port in time.");
  }

  /** Open a URL in a new tab and return its CDP target id. */
  async openTarget(url) {
    const version = await fetchJson(`${this.cdpEndpoint}/json/version`);
    const browserTarget = version.webSocketDebuggerUrl;
    const created = await this.#sendBrowserCommand(browserTarget, "Target.createTarget", { url });
    const targets = await fetchJson(`${this.cdpEndpoint}/json/list`);
    const match = targets.find((target) => target.id === created.targetId) ?? targets[0];
    if (!match) throw new Error(`No CDP target found for ${url}`);
    return match.id;
  }

  async #sendBrowserCommand(webSocketDebuggerUrl, method, params) {
    const { WebSocket } = await import("node:worker_threads").then(() => globalThis).catch(() => ({}));
    void WebSocket;
    return new Promise((resolve, reject) => {
      const socket = new globalThis.WebSocket(webSocketDebuggerUrl);
      const timer = setTimeout(() => {
        try {
          socket.close();
        } catch {}
        reject(new Error(`CDP ${method} timed out.`));
      }, 30000);
      socket.addEventListener("open", () => {
        socket.send(JSON.stringify({ id: 1, method, params }));
      });
      socket.addEventListener("message", (event) => {
        const message = JSON.parse(typeof event.data === "string" ? event.data : "");
        if (message.id === 1) {
          clearTimeout(timer);
          socket.close();
          if (message.error) reject(new Error(`${method} failed: ${message.error.message}`));
          else resolve(message.result);
        }
      });
      socket.addEventListener("error", () => {
        clearTimeout(timer);
        reject(new Error("CDP websocket error."));
      });
    });
  }

  async close() {
    if (this.child) {
      try {
        this.child.kill("SIGTERM");
      } catch {}
      this.child = undefined;
    }
    if (this.profileDir) {
      await rm(this.profileDir, { recursive: true, force: true }).catch(() => {});
      this.profileDir = undefined;
    }
  }
}

async function fetchJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${url} returned ${response.status}`);
  return response.json();
}
