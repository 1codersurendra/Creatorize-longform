/**
 * SVML authoring for long-form narration-led episodes.
 *
 * Hypit is word-anchored: the Script owns the words, WhisperX projects those
 * words onto the media, and everything else — B-roll, captions, motion
 * graphics — attaches to a *word*, not to a second. That is what makes a
 * 25-minute episode cheap to re-cut: rewrite a line and the picture follows.
 *
 * This module emits that structure. It deliberately reads the live Hypit
 * vocabulary rather than hard-coding element names, so a vocabulary change
 * shows up as a clear error instead of a silently broken render.
 */

/**
 * Package imports and the prefix each one gives its elements.
 *
 * `@hypit/script` is deliberately un-aliased: its surface tag is `<script>`,
 * not `<script:script>`. Every other package is aliased to a short prefix.
 */
export const IMPORTS = [
  [null, "@hypit/script@1"],
  ["text", "@hypit/text@1"],
  ["media", "@hypit/media@1"],
  ["mediaop", "@hypit/media-operations@1"],
  ["whisperx", "@hypit/whisperx@1"],
  ["semantic", "@hypit/narrative-temporal@1"],
  ["time", "@hypit/timeline-author@1"],
  ["visual", "@hypit/visual-track@1"],
  ["audio", "@hypit/audio-track@1"],
  ["caption", "@hypit/caption@1"],
  ["caption-fine", "@hypit/caption-fine@1"],
  ["narrative-caption", "@hypit/narrative-caption@1"],
  ["fonts", "@hypit/fontsource@1"],
  ["space", "@hypit/spatial@1"],
  ["film", "@hypit/film@1"],
  ["html", "@hypit/html-video@1"],
];

export function escapeXml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

/**
 * Escape for a Script raw body.
 *
 * A Script Segment owns its own punctuation, so only the characters XML
 * actually requires are escaped. Quotes and apostrophes stay literal - a
 * Script body is prose, not an attribute value.
 */
export function escapeText(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/** A minimal, well-formed XML writer for the SVML shapes Creatorize emits. */
export class XmlWriter {
  constructor({ indent = "  " } = {}) {
    this.lines = [];
    this.indent = indent;
    this.depth = 0;
  }

  push(line) {
    this.lines.push(`${this.indent.repeat(this.depth)}${line}`);
    return this;
  }

  open(tag, attrs = {}, { selfClose = false } = {}) {
    const rendered = renderAttrs(attrs);
    if (selfClose) {
      this.push(`<${tag}${rendered}/>`);
    } else {
      this.push(`<${tag}${rendered}>`);
      this.depth += 1;
    }
    return this;
  }

  close(tag) {
    this.depth = Math.max(0, this.depth - 1);
    this.push(`</${tag}>`);
    return this;
  }

  leaf(tag, attrs = {}) {
    this.push(`<${tag}${renderAttrs(attrs)}/>`);
    return this;
  }

  text(tag, value) {
    this.push(`<${tag}>${escapeXml(value)}</${tag}>`);
    return this;
  }

  raw(line) {
    this.push(line);
    return this;
  }

  comment(text) {
    this.push(`<!-- ${text} -->`);
    return this;
  }

  toString() {
    return this.lines.join("\n");
  }
}

function renderAttrs(attrs) {
  const parts = [];
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (value === true) {
      parts.push(key);
      continue;
    }
    parts.push(`${key}=${renderValue(value)}`);
  }
  return parts.length ? ` ${parts.join(" ")}` : "";
}

/**
 * SVML distinguishes a graph reference from a string by the braces, not by the
 * quotes: `within={canvas.bounds}` is a reference, `within="canvas.bounds"` is
 * text. A brace-wrapped value is therefore written unquoted.
 */
function renderValue(value) {
  const text = String(value);
  if (/^\{[^{}]*\}$/.test(text)) {
    const path = text
      .slice(1, -1)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    return `{${path}}`;
  }
  return `"${escapeXml(value)}"`;
}

/**
 * Build the Script block. `||` starts a new Caption Cue inside a Segment;
 * `@{name}` marks a semantic Moment another layer can answer.
 *
 * A Role Cue is a bare turn marker: it applies until the next Role Cue or the
 * end of its Segment, so it is never closed.
 */
export function buildScript(sections, { segmentId = "story" } = {}) {
  const writer = new XmlWriter();
  writer.open("script", { id: segmentId });
  for (const section of sections) {
    writer.open(section.id);
    const body = section.spoken ?? "";
    writer.raw(`<HOST> ${escapeText(body)}`);
    writer.close(section.id);
  }
  writer.close("script");
  return writer.toString();
}

/**
 * Compose the full long-form Source.
 *
 * @param {object} options
 * @param {object[]} options.sections   plan sections, each { id, role, spoken, broll[] }
 * @param {object} options.longform     { width, height, frameRate, language }
 * @param {string} options.recipeFile   the .svs file name to import
 * @param {string} options.narrationSrc relative path to the narration audio
 * @param {object[]} options.broll      prepared B-roll clips { id, src, sectionId }
 * @param {object} options.assets       extra media declarations { id, src, kind }
 */
export function buildLongformSource(options) {
  const {
    sections,
    longform = {},
    recipeFile = "longform.svs",
    recipePath = `../recipes/${recipeFile}`,
    narrationDir = "../assets/narration",
    broll = [],
    assets = [],
    captionStyle = "primary-caption",
    fontPackage = "@fontsource-variable/inter",
    fontWeight = "800",
    look = "look",
  } = options;

  const width = longform.width ?? 1920;
  const height = longform.height ?? 1080;
  const frameRate = longform.frameRate ?? 30;
  const language = longform.language ?? "en";
  const last = sections[sections.length - 1];

  const w = new XmlWriter();
  w.raw('<?svml using="@hypit/markup@1"?>');
  w.open("svml");
  for (const [alias, module] of IMPORTS) {
    w.leaf("import", alias ? { as: alias, from: module } : { from: module });
  }
  w.leaf("import", { as: look, source: recipePath });

  w.comment("The words. Everything else attaches to these, not to a second.");
  w.raw(buildScript(sections));

  w.comment("Canvas and clock.");
  w.leaf("space:Canvas", { id: "canvas", width, height });
  w.leaf("time:Clock", { id: "clock", "frame-rate": frameRate });
  w.leaf("space:Frame", {
    id: "full",
    within: "{canvas.bounds}",
    left: "0%",
    top: "0%",
    right: "100%",
    bottom: "100%",
  });

  w.comment("Extra prepared material (music bed, stingers, stills).");
  for (const asset of assets) {
    const tag =
      asset.kind === "video" ? "media:Video" : asset.kind === "image" ? "media:Image" : "media:Audio";
    w.leaf(tag, { id: asset.id, src: asset.src });
    if (asset.kind !== "image" && asset.normalize !== false) {
      w.leaf("mediaop:Normalize", {
        id: `${asset.id}-media`,
        source: `{${asset.id}}`,
        clock: "{clock}",
        video: asset.kind === "video" ? "primary-moving" : "none",
        audio: asset.kind === "video" ? "none" : "default",
        "span-authority": asset.kind === "video" ? "video" : "audio",
      });
    }
  }

  w.comment("Narration: one slice per section, so each section knows its own length.");
  for (const section of sections) {
    w.leaf("media:Audio", { id: `narration-${section.id}`, src: `${narrationDir}/${section.id}.m4a` });
    w.leaf("mediaop:Normalize", {
      id: `narration-${section.id}-media`,
      source: `{narration-${section.id}}`,
      clock: "{clock}",
      video: "none",
      audio: "default",
      "span-authority": "audio",
    });
  }

  w.comment("B-roll: each clip is a normal source the picture track can cut to.");
  for (const clip of broll) {
    w.leaf("media:Video", { id: `${clip.id}-source`, src: clip.src });
    w.leaf("mediaop:Normalize", {
      id: `${clip.id}-media`,
      source: `{${clip.id}-source}`,
      clock: "{clock}",
      video: "primary-moving",
      audio: "none",
      "span-authority": "video",
    });
  }

  w.comment("Alignment: each section's words projected onto its own audio.");
  for (const section of sections) {
    w.leaf("whisperx:Alignment", {
      id: `align-${section.id}`,
      narrative: "{story}",
      segment: `{story.segment.${section.id}}`,
      media: `{narration-${section.id}-media.media}`,
      domain: `{narration-${section.id}-media.domain}`,
      language,
    });
  }

  w.comment("Timeline: one window per section, laid end to end.");
  w.open("time:Timeline", {
    id: "program",
    clock: "{clock}",
    end: `${last.id}.end+2s`,
  });
  sections.forEach((section, index) => {
    w.leaf("time:Window", {
      id: section.id,
      from: index === 0 ? "start" : `${sections[index - 1].id}.end`,
      for: `{narration-${section.id}-media.extent}`,
    });
  });
  for (const clip of broll) {
    const section = sections.find((candidate) => candidate.id === clip.sectionId);
    if (!section) continue;
    const offset = clip.atSeconds ?? 0;
    const duration = clip.durationSeconds ?? 4;
    w.leaf("time:Window", {
      id: `shot-${clip.id}`,
      from: offset > 0 ? `${section.id}.start+${round(offset)}s` : `${section.id}.start`,
      for: `${round(duration)}s`,
    });
  }
  w.close("time:Timeline");

  w.comment("Projection: words now have a position on the timeline.");
  w.open("semantic:Projection", { id: "story-time", narrative: "{story}", timeline: "{program.timeline}" });
  for (const section of sections) {
    w.leaf("semantic:Map", {
      alignment: `{align-${section.id}.alignment}`,
      domain: `{narration-${section.id}-media.domain}`,
      window: `{program.${section.id}}`,
    });
  }
  w.close("semantic:Projection");

  w.comment("Sound: the narration, plus any music bed.");
  w.open("audio:Track", { id: "narration-sound", timeline: "{program.timeline}" });
  for (const section of sections) {
    w.leaf("audio:Clip", {
      id: `narration-${section.id}`,
      source: `{narration-${section.id}-media.media}`,
      during: `{program.${section.id}}`,
    });
  }
  w.close("audio:Track");

  w.comment("Picture: B-roll sits under the narration, caption sits above it.");
  w.open("visual:Track", { id: "picture", timeline: "{program.timeline}" });
  for (const clip of broll) {
    w.leaf("visual:Clip", {
      id: `shot-${clip.id}`,
      media: `{${clip.id}-media.media}`,
      during: `{program.shot-${clip.id}}`,
      frame: "{full}",
      z: "0",
      fit: "cover",
    });
  }
  w.close("visual:Track");

  w.comment("Caption: spoken text, word-anchored, karaoke by default.");
  w.leaf("fonts:Face", {
    id: "caption-font",
    package: fontPackage,
    weight: fontWeight,
    style: "normal",
  });
  w.leaf("caption-fine:Style", {
    id: captionStyle,
    recipe: `{${look}.caption.primary}`,
    font: "{caption-font}",
  });
  w.leaf("narrative-caption:Timing", {
    id: "story-captions",
    document: "{story.caption}",
    binding: "{story.caption-binding}",
    projection: "{story-time}",
  });
  w.open("caption-fine:Caption", {
    id: "captions",
    document: "{story.caption}",
    timing: "{story-captions}",
    timeline: "{program.timeline}",
    within: "{canvas.bounds}",
  });
  w.leaf("caption-fine:Use", { style: `{${captionStyle}}` });
  w.close("caption-fine:Caption");

  w.comment("Film and render.");
  w.open("film:Film", {
    id: "main",
    canvas: "{canvas.canvas}",
    timeline: "{program.timeline}",
    appearance: `{${look}.film.main}`,
  });
  w.leaf("film:Track", { source: "{picture.visual}" });
  w.leaf("film:Track", { source: "{narration-sound.audio}" });
  w.leaf("film:Track", { source: "{captions.visual}" });
  w.close("film:Film");
  w.leaf("html:Video", { id: "final", composition: "{main.composition}", timeline: "{program.timeline}" });

  w.close("svml");
  return w.toString();
}

function round(value) {
  return Math.round(value * 100) / 100;
}

/** The recipe sheet that gives the episode its look. */
export function buildRecipeSheet({ background = "#0B0D12", caption = {} } = {}) {
  const captionRule = {
    "stack-order": 70,
    x: 0.5,
    y: 0.84,
    width: 0.88,
    height: 0.12,
    "anchor-x": "center",
    "anchor-y": "bottom",
    align: "center",
    "block-align": "end",
    "inline-size": "fixed",
    wrap: "word",
    size: 64,
    "line-height": 1.08,
    fill: "#F4F1EC",
    "stroke-color": "#0B0D12",
    "stroke-width": 7,
    "shadow-color": "#000000",
    "shadow-opacity": 0.55,
    "shadow-x": 3,
    "shadow-y": 4,
    "shadow-blur": 0,
    "shadow-spread": 0,
    "active-fill": "#FFD54A",
    background: "#00000000",
    padding: "0",
    radius: 0,
    // karaoke accepts off | current | trail.
    karaoke: "current",
    "karaoke-transition": "step",
    "cue-enter": "fade",
    "cue-enter-frames": 3,
    "cue-exit": "none",
    "cue-exit-frames": 0,
    "lead-frames": 0,
    "tail-frames": 0,
    handoff: "cut",
    ...caption,
  };
  return `<?svml using="@hypit/recipe@1"?>
<sheet version="1">
  film.main { background: ${background}; }
  media.cover { fit: cover; stack-order: 0; }
  caption.primary {
${formatRule(captionRule)}
  }
</sheet>
`;
}

function formatRule(rule) {
  return Object.entries(rule)
    .map(([key, value]) => `    ${key}: ${formatValue(value)};`)
    .join("\n");
}

function formatValue(value) {
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (typeof value !== "string") return JSON.stringify(value);
  // A numeric string stays a string: `padding: "0"` is not `padding: 0`.
  if (/^-?\d+(\.\d+)?$/.test(value)) return JSON.stringify(value);
  // A simple bare word needs no quotes; anything else does.
  if (/^[A-Za-z][A-Za-z0-9_#-]*$/.test(value)) return value;
  return JSON.stringify(value);
}

/**
 * The Run that selects the Source and names the output.
 *
 * `<target output="...">` names a *Source export*, not a filename. The Source
 * publishes its rendered film as `{final.video}` (the `html:Video` element's
 * id plus its port), so that is what the Run targets. The file name is chosen
 * later, when the Output is exported.
 */
export function buildRun({ sourcePath = "../authors/episode.svml", output = "final.video" } = {}) {
  return `<?svml using="@hypit/markup/run@1"?>
<svrun version="1">
  <author source="${sourcePath}"/>
  <target output="${output}"/>
</svrun>
`;
}

/**
 * A .svrun that renders only part of the timeline. Long-form renders are long;
 * a ranged build is how a creator checks a section without paying for the
 * whole episode.
 */
export function buildRangeRun({
  sourcePath = "../authors/episode.svml",
  output = "episode-part.mp4",
  from,
  to,
} = {}) {
  return `<?svml using="@hypit/markup/run@1"?>
<svrun version="1">
  <author source="${sourcePath}"/>
  <target output="${output}" from="${from}" until="${to}"/>
</svrun>
`;
}
