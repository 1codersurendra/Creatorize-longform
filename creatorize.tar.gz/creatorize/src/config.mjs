/**
 * Creatorize configuration.
 *
 * Three layers, later ones win:
 *   1. built-in defaults            (src/defaults.mjs)
 *   2. config/creatorize.config.json (the repository's own settings)
 *   3. ~/.creatorize/config.json     (the creator's machine settings)
 *
 * Secrets never live in the repo config. SCENARIO_API_KEY and friends are read
 * from the environment only.
 */
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { homedir } from "node:os";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const REPO_ROOT = resolve(fileURLToPath(import.meta.url), "..", "..");
export const USER_CONFIG_PATH = join(homedir(), ".creatorize", "config.json");
export const TOKEN_STORE_PATH = join(homedir(), ".creatorize", "scenario-token.json");

export const DEFAULTS = {
  version: 1,
  channel: {
    url: "https://www.youtube.com/@thegruss-i8w",
    name: "g russ",
    spec: "config/channels/g-russ.json",
  },
  longform: {
    targetDurationSeconds: 1500, // 25 minutes: the channel's own long-form length
    aspectRatio: "16:9",
    width: 1920,
    height: 1080,
    frameRate: 30,
    language: "en",
    wordsPerMinute: 145,
    sectionCount: 7,
    hookSeconds: 18,
    brollEverySeconds: 7.5,
    captionStyle: "karaoke-word",
  },
  tools: {
    rea: { command: process.env.CREATORIZE_REA_BIN || "rea", args: ["mcp"] },
    scenario: { endpoint: process.env.CREATORIZE_SCENARIO_ENDPOINT || "https://mcp.scenario.com/mcp" },
    hypit: { command: process.env.CREATORIZE_HYPIT_BIN || "hypit" },
    chrome: { path: process.env.CREATORIZE_CHROME || undefined },
  },
  paths: {
    projectRoot: "projects",
    evidenceDir: "evidence",
  },
};

export async function loadConfig({ configPath, overrides = {} } = {}) {
  const layers = [DEFAULTS];
  const repoConfig = join(REPO_ROOT, "config", "creatorize.config.json");
  for (const path of [repoConfig, configPath, USER_CONFIG_PATH]) {
    if (!path) continue;
    if (path !== configPath && !existsSync(path)) continue;
    if (path === configPath && !existsSync(path)) continue;
    const loaded = await readJson(path);
    if (loaded) layers.push(loaded);
  }
  const merged = deepMerge(layers);
  return deepMerge([merged, overrides]);
}

export async function readJson(path) {
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch {
    return undefined;
  }
}

export function deepMerge(layers) {
  const out = {};
  for (const layer of layers) {
    if (!layer || typeof layer !== "object") continue;
    for (const [key, value] of Object.entries(layer)) {
      if (value && typeof value === "object" && !Array.isArray(value)) {
        out[key] = deepMerge([out[key] ?? {}, value]);
      } else if (value !== undefined) {
        out[key] = value;
      }
    }
  }
  return out;
}

/** Resolve a workspace-relative path against the repository root. */
export function resolveInRepo(...parts) {
  return join(REPO_ROOT, ...parts);
}
