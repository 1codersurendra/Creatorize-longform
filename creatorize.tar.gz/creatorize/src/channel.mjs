/**
 * YouTube channel reconnaissance.
 *
 * Reads a public channel page and reconstructs the video catalogue: id, title,
 * runtime, upload date and view count where the page exposes them. No API key
 * is involved; REA is used separately for the *page-level* evidence pass.
 */
import { setTimeout as delay } from "node:timers/promises";

const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

export function parseChannelUrl(input) {
  const value = String(input).trim();
  const handle = value.match(/@([\w.-]+)/)?.[1];
  const channelId = value.match(/channel\/(UC[\w-]+)/)?.[1];
  if (handle) return { kind: "handle", handle, url: `https://www.youtube.com/@${handle}` };
  if (channelId) return { kind: "channel", channelId, url: `https://www.youtube.com/channel/${channelId}` };
  throw new Error(`Could not read a YouTube handle or channel id from "${input}".`);
}

export async function fetchChannelPage(url, { timeoutMs = 30000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      headers: { "User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9" },
      signal: controller.signal,
    });
    if (!response.ok) throw new Error(`YouTube returned ${response.status} for ${url}`);
    return await response.text();
  } finally {
    clearTimeout(timer);
  }
}

export function parseChannelPage(html) {
  const name = html.match(/"name":"([^"]{1,80})","url":"https:\/\/www\.youtube\.com\/channel\/UC/)?.[1];
  const alternate = html.match(/"alternateName":"(@[\w.-]+)"/)?.[1];
  const channelId = html.match(/"channelId":"(UC[\w-]+)"/)?.[1] ??
    html.match(/"url":"https:\/\/www\.youtube\.com\/channel\/(UC[\w-]+)"/)?.[1];
  const description = html.match(/"description":"((?:[^"\\]|\\.){0,400})"/)?.[1];
  const subscribers = html.match(/"subscriberCountText":\{"simpleText":"([\d.,KMB\s]+)/)?.[1] ??
    html.match(/"simpleText":"([\d.,KMB\s]+) subscribers"/)?.[1];

  const videos = parseVideoCatalogue(html);
  return {
    name,
    handle: alternate,
    channelId,
    description: description ? JSON.parse(`"${description}"`) : undefined,
    subscribers,
    videos,
  };
}

/**
 * Walk the channel page for the video catalogue.
 *
 * YouTube's "Videos" tab renders each entry as a `lockupViewModel` whose
 * thumbnail URL carries the video id, whose thumbnail badge carries the
 * runtime, and whose metadata block carries the title, view count and upload
 * age. Parsing the lockup keeps those three facts together; a global scan
 * would scatter them across the page.
 */
export function parseVideoCatalogue(html) {
  const videos = [];
  const seen = new Set();

  const push = (id, fields) => {
    if (!id || seen.has(id)) return;
    seen.add(id);
    videos.push({
      id,
      title: fields.title,
      duration: fields.duration,
      durationSeconds: fields.duration ? durationToSeconds(fields.duration) : undefined,
      views: fields.views,
      published: fields.published,
    });
  };

  for (const block of html.split('"lockupViewModel"').slice(1)) {
    const chunk = block.slice(0, 12000);
    const id =
      chunk.match(/i\.ytimg\.com\/vi\/([\w-]{11})\//)?.[1] ??
      chunk.match(/"videoId":"([\w-]{11})"/)?.[1];
    if (!id) continue;
    const title = chunk.match(/"lockupMetadataViewModel":\{"title":\{"content":"((?:[^"\\]|\\.)*)"/)?.[1];
    const duration = chunk.match(/"thumbnailBadgeViewModel":\{"text":"(\d{1,2}:\d{2}(?::\d{2})?)"/)?.[1];
    const views =
      chunk.match(/"text":\{"content":"([\d.,]+[KMB]?)"\},"accessibilityLabel":"[^"]*views"/)?.[1] ??
      chunk.match(/"accessibilityLabel":"([\d.,]+[KMB]?) views"/)?.[1];
    const published =
      chunk.match(/"text":\{"content":"([^"]+)"\},"accessibilityLabel":"([^"]+ ago)"/)?.[2] ??
      chunk.match(/"accessibilityLabel":"([^"]+ ago)"/)?.[1];
    push(id, {
      title: title ? JSON.parse(`"${title}"`) : undefined,
      duration,
      views,
      published,
    });
  }

  // Older layouts put the id in a plain field next to a simple title.
  if (videos.length === 0) {
    for (const block of html.matchAll(/"videoId":"([\w-]{11})"[\s\S]{0,3000}?"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.){1,200})"/g)) {
      push(block[1], { title: JSON.parse(`"${block[2]}"`) });
    }
  }

  return videos;
}

export function durationToSeconds(value) {
  if (!value) return undefined;
  const parts = value.split(":").map(Number);
  if (parts.some(Number.isNaN)) return undefined;
  return parts.reduce((total, part) => total * 60 + part, 0);
}

/**
 * Read a video's own chapter list.
 *
 * Chapters are the channel's own statement of how a long-form episode is
 * built. They are the single most useful signal for reconstructing the
 * format: a creator who titles their sections has already decided the spine.
 */
export function extractChapters(html) {
  const pattern =
    /"macroMarkersListItemRenderer":\{"title":\{"simpleText":"((?:[^"\\]|\\.)*)"[\s\S]{0,600}?"timeDescription":\{"simpleText":"(\d{1,2}:\d{2}(?::\d{2})?)"/g;
  const chapters = [];
  const seen = new Set();
  for (const match of html.matchAll(pattern)) {
    const title = JSON.parse(`"${match[1]}"`);
    if (seen.has(title)) continue;
    seen.add(title);
    chapters.push({ title, at: match[2], atSeconds: durationToSeconds(match[2]) });
  }
  if (chapters.length > 0) return chapters;

  // Older layout: chapters live in a `chapters` array of {title, startMillis}.
  const array = html.match(/"chapters":\[([\s\S]{0,20000}?)\]/);
  if (array) {
    for (const match of array[1].matchAll(
      /"title":\{"simpleText":"((?:[^"\\]|\\.)*)"\},"startMillis":"(\d+)"/g,
    )) {
      chapters.push({
        title: JSON.parse(`"${match[1]}"`),
        atSeconds: Number(match[2]) / 1000,
        at: formatDuration(Number(match[2]) / 1000),
      });
    }
  }
  return chapters;
}

/** Fetch one watch page and read its chapters. */
export async function fetchChapters(videoId, { timeoutMs = 30000 } = {}) {
  const url = `https://www.youtube.com/watch?v=${videoId}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      headers: { "User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9" },
      signal: controller.signal,
    });
    if (!response.ok) return [];
    return extractChapters(await response.text());
  } catch {
    return [];
  } finally {
    clearTimeout(timer);
  }
}

export function formatDuration(seconds) {
  if (!Number.isFinite(seconds)) return "unknown";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.round(seconds % 60);
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

/**
 * Resolve titles for videos whose titles were not present in the channel page.
 * oEmbed is cheap, public and does not need a key.
 */
export async function enrichTitles(videos, { concurrency = 6 } = {}) {
  const queue = [...videos];
  const workers = Array.from({ length: Math.min(concurrency, queue.length || 1) }, async () => {
    while (queue.length) {
      const video = queue.shift();
      if (video.title) continue;
      try {
        const url = `https://www.youtube.com/oembed?url=${encodeURIComponent(
          `https://www.youtube.com/watch?v=${video.id}`,
        )}&format=json`;
        const response = await fetch(url, { headers: { "User-Agent": USER_AGENT } });
        if (!response.ok) continue;
        const data = await response.json();
        video.title = data.title;
        video.author = data.author_name;
      } catch {
        /* leave the title undefined; the caller reports coverage */
      }
      await delay(120);
    }
  });
  await Promise.all(workers);
  return videos;
}

/** Group videos into rough format buckets by runtime. */
export function classifyFormats(videos) {
  const buckets = { short: [], medium: [], long: [], livestream: [] };
  for (const video of videos) {
    const seconds = video.durationSeconds;
    if (!Number.isFinite(seconds)) continue;
    if (seconds >= 3600) buckets.livestream.push(video);
    else if (seconds >= 900) buckets.long.push(video);
    else if (seconds >= 180) buckets.medium.push(video);
    else buckets.short.push(video);
  }
  return buckets;
}

export function summarizeDurations(videos) {
  const values = videos.map((video) => video.durationSeconds).filter(Number.isFinite).sort((a, b) => a - b);
  if (values.length === 0) return undefined;
  const at = (q) => values[Math.min(values.length - 1, Math.floor(q * values.length))];
  return {
    count: values.length,
    min: values[0],
    p25: at(0.25),
    median: at(0.5),
    p75: at(0.75),
    max: values[values.length - 1],
    mean: Math.round(values.reduce((sum, value) => sum + value, 0) / values.length),
  };
}

/**
 * Recover the channel's title *grammar*.
 *
 * Exact-string matching is useless here: no two titles are alike. What
 * repeats is the shape - "<MODEL> + <PRODUCT> = <INTENS> <TOPIC>" - with the
 * free text in each slot changing every time. So the title is decomposed into
 * its slots, the slots that carry a known meaning are named, and the shape is
 * what gets counted.
 */
const MODEL_PATTERN =
  /\b(Opus|Sonnet|Haiku|GPT|Gemini|Grok|Flux|Seedance|Seedream|WhisperX|Veo|Kling|Runway|Ideogram|Imagen|Three\.js)\s?[\d.]*(\s?(?:Mini|Max|Turbo|Lightning))?/gi;
const PRODUCT_PATTERN = /\b(Creatorize|Cretorize|Hypit|Remotion|Sora|Three\.js)\b/gi;
const QUALIFIER_PATTERN =
  /\b(MEGA|GIGA|INSANE|CRAZY|MAD|WILD|EPIC|MASSIVE|ABSOLUTE|ULTIMATE|EASY|VIRAL|LAZIEST|FULLY|BLINDING|BEST|REAL)\b/gi;
const NUMBER_PATTERN = /\b\d+(\.\d+)?\s?(k|m|x|b)?\b/gi;
const PARENTHETICAL_PATTERN = /\s*\([^)]*\)\s*!?\s*$/;
const TRAILING_CLAIM_PATTERN =
  /\b(ON AUTOPILOT|AT EVERY EFFORT LEVEL|IN MINUTES|IN SECONDS|FOR \$0|FULLY AUTOMATIC|FULL SPEEDRUN)\b/gi;

function stripParenthetical(title) {
  return title.replace(PARENTHETICAL_PATTERN, "").trim();
}

function classifySlot(text) {
  const trimmed = text.trim();
  if (!trimmed) return "<EMPTY>";
  if (MODEL_PATTERN.test(trimmed)) {
    MODEL_PATTERN.lastIndex = 0;
    return "<MODEL>";
  }
  MODEL_PATTERN.lastIndex = 0;
  if (PRODUCT_PATTERN.test(trimmed)) {
    PRODUCT_PATTERN.lastIndex = 0;
    return "<PRODUCT>";
  }
  PRODUCT_PATTERN.lastIndex = 0;
  if (QUALIFIER_PATTERN.test(trimmed)) {
    QUALIFIER_PATTERN.lastIndex = 0;
    return "<INTENS>";
  }
  QUALIFIER_PATTERN.lastIndex = 0;
  if (NUMBER_PATTERN.test(trimmed)) {
    NUMBER_PATTERN.lastIndex = 0;
    return "<N>";
  }
  NUMBER_PATTERN.lastIndex = 0;
  return "<X>";
}

function classifyTopic(text) {
  let value = stripParenthetical(text).trim();
  value = value.replace(TRAILING_CLAIM_PATTERN, "").trim();
  const qualifier = value.match(QUALIFIER_PATTERN);
  if (qualifier) {
    value = value.replace(QUALIFIER_PATTERN, "").trim();
    return "<INTENS> <TOPIC>";
  }
  if (NUMBER_PATTERN.test(value)) {
    NUMBER_PATTERN.lastIndex = 0;
    return "<N> <TOPIC>";
  }
  NUMBER_PATTERN.lastIndex = 0;
  return "<TOPIC>";
}

/** Decompose one title into its shape. */
export function titleShape(title) {
  if (!title) return undefined;
  const cleaned = stripParenthetical(title).replace(/!+$/, "").trim();

  const equation = cleaned.match(/^(.+?)\s*\+\s*(.+?)\s*=\s*(.+)$/);
  if (equation) {
    return `${classifySlot(equation[1])} + ${classifySlot(equation[2])} = ${classifyTopic(equation[3])}`;
  }

  const howTo = cleaned.match(/^How\s+To\s+(.+)$/i);
  if (howTo) return `How To Make ${classifyTopic(howTo[1])}`;

  const how = cleaned.match(/^How\s+(.+)$/i);
  if (how) return `How ${classifyTopic(how[1])}`;

  const make = cleaned.match(/^Make\s+(.+)$/i);
  if (make) return `Make ${classifyTopic(make[1])}`;

  const build = cleaned.match(/^Build\s+(.+)$/i);
  if (build) return `Build ${classifyTopic(build[1])}`;

  const iTested = cleaned.match(/^I\s+tested\s+(.+)$/i);
  if (iTested) return `I tested ${classifyTopic(iTested[1])}`;

  return `${classifySlot(cleaned)} ${classifyTopic("")}`.trim();
}

export function deriveTitleFormulas(titles) {
  const shapes = new Map();
  for (const title of titles) {
    if (!title) continue;
    const shape = titleShape(title);
    if (!shape) continue;
    shapes.set(shape, (shapes.get(shape) ?? 0) + 1);
  }
  return [...shapes.entries()]
    .filter(([, count]) => count > 1)
    .sort((a, b) => b[1] - a[1])
    .map(([formula, count]) => ({ formula, count }));
}

export function deriveTopicClusters(titles) {
  const stop = new Set([
    "the", "a", "an", "and", "or", "for", "to", "of", "in", "on", "with", "my", "i", "this",
    "that", "how", "what", "why", "at", "is", "it", "you", "your", "full", "guide", "new",
  ]);
  const counts = new Map();
  for (const title of titles ?? []) {
    if (!title) continue;
    for (const word of title.toLowerCase().match(/[a-z][a-z0-9+#.-]{2,}/g) ?? []) {
      if (stop.has(word)) continue;
      counts.set(word, (counts.get(word) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 24)
    .map(([term, count]) => ({ term, count }));
}
