/**
 * REA adapter.
 *
 * REA (github.com/morluto/rea) is an MCP server + CLI for reverse engineering.
 * It speaks JSONL over stdio as `rea mcp`. 207 tools are exposed; the ones
 * that matter for Creatorize are the web/JS family and the artifact family.
 *
 * Division of labour in the pipeline:
 *   - REA  -> read the *reference* (a channel page, a video page, a shipped app)
 *             and produce evidence about how it actually works.
 *   - Hypit-> author and render the new work.
 *   - Scenario -> generate the material.
 */
import { McpStdioClient } from "../mcp/stdio.mjs";

const REA_BIN = process.env.CREATORIZE_REA_BIN || "rea";

export class ReaClient {
  constructor({ command = REA_BIN, args = ["mcp"], env } = {}) {
    this.mcp = new McpStdioClient({
      command,
      args,
      // A real channel page produces a very large evidence record. REA's
      // default heap is not enough for it, and the server dies with SIGABRT
      // mid-capture, which looks like a tool failure rather than a limit.
      // The script-bundle analysis needs more again; raise it with
      // CREATORIZE_REA_HEAP on a host with the memory for it.
      env: {
        NODE_OPTIONS: `--max-old-space-size=${process.env.CREATORIZE_REA_HEAP || "2048"}`,
        ...env,
      },
      clientName: "creatorize",
      clientVersion: "0.1.0",
    });
  }

  static async connect(options) {
    const client = new ReaClient(options);
    await client.mcp.start();
    return client;
  }

  get serverInfo() {
    return this.mcp.serverInfo;
  }

  async listTools(options) {
    return this.mcp.listTools(options);
  }

  async call(name, args = {}) {
    return this.mcp.callTool(name, args);
  }

  /** Convenience: the exact tool inventory Creatorize relies on. */
  async capabilities() {
    const tools = await this.listTools();
    const names = new Set(tools.map((tool) => tool.name));
    const wanted = [
      "list_browser_targets",
      "inspect_web_page",
      "analyze_web_bundle",
      "capture_web_screenshot",
      "capture_browser_scenario",
      "export_web_scripts",
      "observe_web_session",
      "compare_web_captures",
      "open_binary",
      "inspect_artifact",
      "binary_overview",
      "list_strings",
      "list_procedures",
      "procedure_pseudo_code",
      "trace_feature",
      "analyze_javascript_application",
      "inspect_analysis_view",
    ];
    return {
      total: tools.length,
      server: this.mcp.serverInfo,
      present: wanted.filter((name) => names.has(name)),
      missing: wanted.filter((name) => !names.has(name)),
    };
  }

  /**
   * Passive inspection of one page target.
   * REA refuses anything that is not a literal loopback CDP endpoint, so the
   * caller must own the browser lifecycle (see src/browser.mjs).
   */
  async inspectPage(cdpEndpoint, targetId, options = {}) {
    return this.call("inspect_web_page", {
      cdp_endpoint: cdpEndpoint,
      target_id: targetId,
      allowed_origins: options.allowedOrigins,
      observation_ms: options.observationMs ?? 800,
      include_accessibility_text: options.accessibilityText ?? true,
      include_console_text: options.consoleText ?? false,
      include_json_body_shapes: options.jsonBodyShapes ?? false,
      include_storage_keys: options.storageKeys ?? false,
      include_script_sources: options.scriptSources ?? false,
    });
  }

  async listTargets(cdpEndpoint, allowedOrigins) {
    return this.call("list_browser_targets", {
      cdp_endpoint: cdpEndpoint,
      allowed_origins: allowedOrigins,
    });
  }

  async analyzeBundle(cdpEndpoint, targetId, options = {}) {
    // `detail` is not part of this tool's input schema; passing it is an
    // "Unrecognized key" error. Only the accepted keys are sent.
    const args = {
      cdp_endpoint: cdpEndpoint,
      target_id: targetId,
    };
    if (options.allowedOrigins) args.allowed_origins = options.allowedOrigins;
    return this.call("analyze_web_bundle", args);
  }

  async screenshot(cdpEndpoint, targetId) {
    return this.call("capture_web_screenshot", {
      cdp_endpoint: cdpEndpoint,
      target_id: targetId,
    });
  }

  /** Open a local artifact (the Creatorize desktop app, an ASAR, a binary). */
  async openBinary(path, options = {}) {
    return this.call("open_binary", { path, ...options });
  }

  async overview() {
    return this.call("binary_overview", {});
  }

  async strings(pattern) {
    return this.call("list_strings", pattern ? { pattern } : {});
  }

  async procedures(pattern) {
    return this.call("list_procedures", pattern ? { pattern } : {});
  }

  async pseudoCode(procedure) {
    return this.call("procedure_pseudo_code", { procedure });
  }

  async close() {
    await this.mcp.close();
  }
}
