/**
 * Hypit adapter.
 *
 * Hypit (github.com/hypit-ai/hypit) is the video language + runtime. It owns
 * the script, the word-anchored timeline, captions, B-roll, motion graphics and
 * the render. Creatorize hands it a Source (.svml), a Recipe sheet (.svs) and
 * a Run (.svrun), then drives the build.
 *
 * All calls go through the `hypit` executable. Hypit is distributed on npm as
 * `@hypit/hypit` and exposes the `hypit` binary.
 */
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { mkdir } from "node:fs/promises";
import { dirname } from "node:path";

const execFileAsync = promisify(execFile);

const HYPIT_BIN = process.env.CREATORIZE_HYPIT_BIN || "hypit";

export class HypitClient {
  constructor({ command = HYPIT_BIN, cwd } = {}) {
    this.command = command;
    this.cwd = cwd;
  }

  async run(args, { cwd, json = false, timeoutMs = 900000, input } = {}) {
    const full = json ? [...args, "--json"] : args;
    try {
      const { stdout, stderr } = await execFileAsync(this.command, full, {
        cwd: cwd ?? this.cwd,
        timeout: timeoutMs,
        maxBuffer: 64 * 1024 * 1024,
        env: process.env,
        input,
      });
      const out = { ok: true, stdout, stderr, args: full };
      if (json) {
        const parsed = tryJson(stdout);
        if (parsed !== undefined) out.data = parsed;
      }
      return out;
    } catch (error) {
      const stdout = error.stdout ?? "";
      const stderr = error.stderr ?? "";
      const failure = new Error(
        `hypit ${full.join(" ")} failed (${error.code ?? "error"}):\n${stderr || stdout}`.slice(0, 4000),
      );
      failure.stdout = stdout;
      failure.stderr = stderr;
      failure.exitCode = error.code;
      if (json) {
        const parsed = tryJson(stdout);
        if (parsed !== undefined) failure.data = parsed;
      }
      throw failure;
    }
  }

  async version() {
    return this.run(["version"], { json: true, timeoutMs: 120000 });
  }

  async paths(cwd) {
    return this.run(["paths"], { cwd, json: true, timeoutMs: 120000 });
  }

  async doctor(cwd) {
    return this.run(["doctor"], { cwd, json: true, timeoutMs: 300000 });
  }

  /** Prepare yt-dlp once, then download a reference video. */
  async prepareDownloader(cwd) {
    return this.run(["download", "prepare"], { cwd, json: true, timeoutMs: 900000 });
  }

  async download(url, to, { cwd } = {}) {
    await mkdir(dirname(to), { recursive: true });
    return this.run(["download", url, "--to", to], { cwd, json: true, timeoutMs: 1800000 });
  }

  async transcribe(input, { cwd, language = "en", output } = {}) {
    const args = ["transcribe", input, "--language", language];
    if (output) args.push("--to", output);
    return this.run(args, { cwd, json: true, timeoutMs: 1800000 });
  }

  async probe(input, { cwd } = {}) {
    return this.run(["media", "probe", input], { cwd, json: true, timeoutMs: 300000 });
  }

  async frames(input, { cwd, start, end, every = 1, to } = {}) {
    const args = ["media", "frames", input];
    if (start !== undefined) args.push("--start", String(start));
    if (end !== undefined) args.push("--end", String(end));
    if (every !== undefined) args.push("--every", String(every));
    if (to) {
      await mkdir(dirname(to), { recursive: true });
      args.push("--to", to);
    }
    return this.run(args, { cwd, json: true, timeoutMs: 600000 });
  }

  async tiles(input, { cwd, start, end, every, columns = 4, rows = 3, cell = 480, transcript, to } = {}) {
    const args = ["media", "tiles", input];
    if (start !== undefined) args.push("--start", String(start));
    if (end !== undefined) args.push("--end", String(end));
    if (every !== undefined) args.push("--every", String(every));
    args.push("--columns", String(columns), "--rows", String(rows), "--cell", String(cell));
    if (transcript) args.push("--transcript", transcript);
    if (to) {
      await mkdir(dirname(to), { recursive: true });
      args.push("--to", to);
    }
    return this.run(args, { cwd, json: true, timeoutMs: 900000 });
  }

  async boundaries(input, { cwd, to } = {}) {
    const args = ["media", "boundaries", input];
    if (to) {
      await mkdir(dirname(to), { recursive: true });
      args.push("--to", to);
    }
    return this.run(args, { cwd, json: true, timeoutMs: 600000 });
  }

  /** Validate a Source before spending a build. */
  async check(source, { cwd } = {}) {
    return this.run(["check", source], { cwd, json: true, timeoutMs: 600000 });
  }

  async plan(runSource, { cwd } = {}) {
    return this.run(["plan", runSource], { cwd, json: true, timeoutMs: 600000 });
  }

  async build(runSource, { cwd, follow = true } = {}) {
    const args = ["build", runSource];
    if (follow) args.push("--follow");
    return this.run(args, { cwd, json: true, timeoutMs: 7200000 });
  }

  async builds({ cwd } = {}) {
    return this.run(["builds"], { cwd, json: true, timeoutMs: 300000 });
  }

  async status(buildId, { cwd, watch = false } = {}) {
    const args = ["status", buildId];
    if (watch) args.push("--watch");
    return this.run(args, { cwd, json: true, timeoutMs: 600000 });
  }

  async logs(buildId, { cwd, lines = 200 } = {}) {
    return this.run(["logs", buildId, "--lines", String(lines)], { cwd, json: true, timeoutMs: 300000 });
  }

  async inspect(buildId, { cwd } = {}) {
    return this.run(["inspect", buildId], { cwd, json: true, timeoutMs: 600000 });
  }

  /** Export one named Output of a finished build. */
  async get(buildId, output, to, { cwd } = {}) {
    await mkdir(dirname(to), { recursive: true });
    return this.run(["get", buildId, "--output", output, "--to", to], {
      cwd,
      json: true,
      timeoutMs: 1800000,
    });
  }

  async installBrowser({ cwd } = {}) {
    return this.run(["capture", "install-browser"], { cwd, json: true, timeoutMs: 1800000 });
  }

  async authStatus({ cwd } = {}) {
    return this.run(["auth", "status"], { cwd, json: true, timeoutMs: 300000 });
  }
}

function tryJson(text) {
  if (typeof text !== "string") return undefined;
  const trimmed = text.trim();
  if (!trimmed) return undefined;
  try {
    return JSON.parse(trimmed);
  } catch {
    // Hypit may print banners before the JSON payload.
    const first = trimmed.indexOf("{");
    const last = trimmed.lastIndexOf("}");
    if (first >= 0 && last > first) {
      try {
        return JSON.parse(trimmed.slice(first, last + 1));
      } catch {
        return undefined;
      }
    }
    return undefined;
  }
}
