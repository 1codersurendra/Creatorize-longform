/**
 * Scenario adapter.
 *
 * Scenario's MCP server (https://mcp.scenario.com/mcp) exposes a small default
 * tool set plus a catalog that is discovered at runtime:
 *   - `scenario_tools_search` finds assets, models and workflows.
 *   - `scenario_tool_execute_*` runs a discovered tool.
 * Connecting with `?toolsets=full` lists every tool directly.
 *
 * The execute tool's argument shape is discovered from its own input schema at
 * runtime, so Creatorize adapts instead of hard-coding a guess.
 */
import { McpHttpClient } from "../mcp/http.mjs";

const ENDPOINT = process.env.CREATORIZE_SCENARIO_ENDPOINT || "https://mcp.scenario.com/mcp";
const FULL_ENDPOINT = ENDPOINT.includes("?")
  ? `${ENDPOINT}&toolsets=full`
  : `${ENDPOINT}?toolsets=full`;

export class ScenarioClient {
  constructor({ endpoint = ENDPOINT, accessToken, tokenStorePath, onAuthRequired } = {}) {
    this.mcp = new McpHttpClient({
      endpoint,
      accessToken,
      tokenStorePath,
      onAuthRequired,
    });
  }

  static async connect({ endpoint, accessToken, tokenStorePath, onAuthRequired, auth = true } = {}) {
    const client = new ScenarioClient({ endpoint, accessToken, tokenStorePath, onAuthRequired });
    if (auth) await client.mcp.authenticate();
    await client.mcp.start();
    return client;
  }

  get serverInfo() {
    return this.mcp.serverInfo;
  }

  async listTools(options) {
    return this.mcp.listTools(options);
  }

  /** The catalog tool, whichever name the server exposes it under. */
  async findTools(query, { limit = 20 } = {}) {
    const searchTool =
      (await this.#findTool((name) => name === "scenario_tools_search")) ??
      (await this.#findTool((name) => name.endsWith("tools_search")));
    if (!searchTool) {
      throw new Error(
        "Scenario MCP does not expose a tools_search tool. Connect with ?toolsets=full to list every tool.",
      );
    }
    const args = this.#fitSearchArgs(searchTool, query, limit);
    const result = await this.mcp.callTool(searchTool.name, args);
    return result?.normalized ?? result;
  }

  async #findTool(predicate) {
    const tools = await this.listTools();
    return tools.find((tool) => predicate(tool.name)) ?? null;
  }

  #fitSearchArgs(tool, query, limit) {
    const props = tool.inputSchema?.properties ?? {};
    const required = tool.inputSchema?.required ?? [];
    const args = {};
    for (const name of required) {
      if (props[name]?.type === "array") args[name] = [query];
      else if (props[name]?.type === "number" || props[name]?.type === "integer") args[name] = limit;
      else if (props[name]?.type === "boolean") args[name] = false;
      else args[name] = query;
    }
    if (Object.keys(args).length === 0) {
      args.query = query;
      if (props.limit) args.limit = limit;
    }
    return args;
  }

  /** Run a discovered Scenario tool by its catalog name. */
  async runTool(toolName, args = {}) {
    const executeTool =
      (await this.#findTool((name) => name === `scenario_tool_execute_${toolName}`)) ??
      (await this.#findTool((name) => name.startsWith("scenario_tool_execute_"))) ??
      (await this.#findTool((name) => name === toolName));
    if (!executeTool) {
      throw new Error(`Scenario tool "${toolName}" is not available on this server.`);
    }
    const payload = this.#fitExecuteArgs(executeTool, toolName, args);
    const result = await this.mcp.callTool(executeTool.name, payload);
    return result?.normalized ?? result;
  }

  /**
   * Build the execute call from the live schema. Scenario's execute tool takes
   * the target tool name plus an argument object; the exact keys are read from
   * the schema rather than assumed.
   */
  #fitExecuteArgs(executeTool, toolName, args) {
    const props = executeTool.inputSchema?.properties ?? {};
    const payload = {};
    const targetKey = Object.keys(props).find((key) => /^(tool|tool_name|target|name)$/i.test(key));
    const argKey = Object.keys(props).find((key) => /^(arguments|args|input|inputs|params|parameters|body)$/i.test(key));
    if (targetKey) payload[targetKey] = toolName;
    if (argKey) payload[argKey] = args;
    if (!targetKey && !argKey) {
      // Unknown shape: send both flat and nested so one of them lands.
      payload.tool = toolName;
      payload.arguments = args;
    }
    for (const key of executeTool.inputSchema?.required ?? []) {
      if (payload[key] === undefined) {
        const spec = props[key];
        if (spec?.type === "array") payload[key] = [];
        else if (spec?.type === "object") payload[key] = {};
        else if (spec?.type === "boolean") payload[key] = false;
        else if (spec?.type === "number" || spec?.type === "integer") payload[key] = 0;
        else payload[key] = toolName;
      }
    }
    return payload;
  }

  /** Ask Scenario which model suits a single generation job. */
  async recommendModel(task, { domain = "image" } = {}) {
    const tool =
      (await this.#findTool((name) => name === "model_recommend")) ??
      (await this.#findTool((name) => /recommend.*model/i.test(name)));
    if (!tool) return undefined;
    const props = tool.inputSchema?.properties ?? {};
    const args = {};
    const promptKey = Object.keys(props).find((key) => /prompt|task|query|request|description/i.test(key));
    if (promptKey) args[promptKey] = task;
    const domainKey = Object.keys(props).find((key) => /domain|kind|asset_type|modality|type/i.test(key));
    if (domainKey && props[domainKey]?.enum?.includes(domain)) args[domainKey] = domain;
    for (const key of tool.inputSchema?.required ?? []) {
      if (args[key] === undefined) args[key] = typeof props[key]?.type === "string" ? task : {};
    }
    const result = await this.mcp.callTool(tool.name, args);
    return result?.normalized ?? result;
  }

  /** Generate one asset with a Scenario model. */
  async generate({ prompt, model, domain = "image", options = {} }) {
    const tool =
      (await this.#findTool((name) => name === "model_run")) ??
      (await this.#findTool((name) => /run.*model|model_run/i.test(name)));
    if (!tool) throw new Error("Scenario MCP does not expose a model_run tool.");
    const props = tool.inputSchema?.properties ?? {};
    const args = {};
    const promptKey = Object.keys(props).find((key) => /prompt|input|text/i.test(key));
    if (promptKey) args[promptKey] = prompt;
    const modelKey = Object.keys(props).find((key) => /^model|model_?name|model_?id$/i.test(key));
    if (modelKey && model) args[modelKey] = model;
    const domainKey = Object.keys(props).find((key) => /domain|asset_type|kind|modality/i.test(key));
    if (domainKey && props[domainKey]?.enum?.includes(domain)) args[domainKey] = domain;
    for (const [key, value] of Object.entries(options)) {
      if (props[key]) args[key] = value;
    }
    for (const key of tool.inputSchema?.required ?? []) {
      if (args[key] === undefined) {
        const spec = props[key];
        if (spec?.type === "array") args[key] = [];
        else if (spec?.type === "object") args[key] = {};
        else if (spec?.type === "boolean") args[key] = false;
        else if (spec?.type === "number" || spec?.type === "integer") args[key] = 0;
        else args[key] = prompt;
      }
    }
    const result = await this.mcp.callTool(tool.name, args);
    return result?.normalized ?? result;
  }

  /** Search the Scenario library for an existing asset we can reuse. */
  async searchAssets(query, options = {}) {
    const tool =
      (await this.#findTool((name) => name === "search")) ??
      (await this.#findTool((name) => /asset.*search|search.*asset/i.test(name)));
    if (!tool) return undefined;
    const props = tool.inputSchema?.properties ?? {};
    const args = {};
    const queryKey = Object.keys(props).find((key) => /query|text|search|keyword/i.test(key));
    if (queryKey) args[queryKey] = query;
    for (const [key, value] of Object.entries(options)) {
      if (props[key]) args[key] = value;
    }
    for (const key of tool.inputSchema?.required ?? []) {
      if (args[key] === undefined) args[key] = typeof props[key]?.type === "string" ? query : {};
    }
    const result = await this.mcp.callTool(tool.name, args);
    return result?.normalized ?? result;
  }

  async close() {}
}

export { ENDPOINT as SCENARIO_ENDPOINT, FULL_ENDPOINT as SCENARIO_ENDPOINT_FULL };
