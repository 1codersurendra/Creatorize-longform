/**
 * Creatorize smoke test.
 *
 * Runs the whole chain offline: no network, no credentials, no paid services.
 * The point is to prove the plumbing - the parsers, the planners, the SVML
 * writer and the Hypit adapters - before a creator spends anything.
 *
 *   node test/smoke.mjs
 */
import { mkdtemp, readFile, rm, writeFile, mkdir } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import assert from "node:assert/strict";

import {
  parseChannelPage,
  parseVideoCatalogue,
  extractChapters,
  durationToSeconds,
  formatDuration,
  summarizeDurations,
  classifyFormats,
  deriveTitleFormulas,
  deriveTopicClusters,
} from "../src/channel.mjs";
import { buildPlan, auditPlan, listTemplates } from "../src/pipeline/plan.mjs";
import { buildLongformSource, buildRecipeSheet, buildRun, XmlWriter } from "../src/svml.mjs";
import {
  applyScript,
  writeProject,
  readBrollManifest,
  writeReuseRun,
  writeAlignmentRun,
} from "../src/pipeline/author.mjs";
import { deriveEpisodeRhythm } from "../src/pipeline/analyze.mjs";
import { ALL_PACKAGES } from "../src/pipeline/deps.mjs";

let passed = 0;
let failed = 0;

async function test(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log(`  ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.log(`  FAIL ${name}`);
    console.log(`       ${error.message}`);
  }
}

console.log("\nCreatorize smoke test\n");

// ---------------------------------------------------------------- channel ---

const SAMPLE_CHANNEL_HTML = `
<meta name="description" content="ignored">
<script>var ytInitialData = {"name":"g russ","url":"https://www.youtube.com/channel/UCXvdrBvoz_T36afkGrgIHfg",
"alternateName":"@thegruss-i8w","description":"\\uD83D\\uDC47 Join Now\\n",
"contents":{"items":[{"lockupViewModel":{"contentImage":{"thumbnailViewModel":{
"image":{"sources":[{"url":"https://i.ytimg.com/vi/xj1WSzC0VfA/hq720.jpg"}]},
"overlays":[{"thumbnailBottomOverlayViewModel":{"badges":[{"thumbnailBadgeViewModel":{"text":"25:29"}}]}}]}},
"metadata":{"lockupMetadataViewModel":{"title":{"content":"Opus 5.5 + Creatorize = MEGA Viral Stickman Animations!"},
"metadata":{"contentMetadataViewModel":{"metadataRows":[{"metadataParts":[
{"text":{"content":"1.2K"},"accessibilityLabel":"1.2 thousand views"},
{"text":{"content":"4h ago"},"accessibilityLabel":"4 hours ago"}]}]}}}}},
{"lockupViewModel":{"contentImage":{"thumbnailViewModel":{
"image":{"sources":[{"url":"https://i.ytimg.com/vi/L91urcNbspU/hq720.jpg"}]},
"overlays":[{"thumbnailBottomOverlayViewModel":{"badges":[{"thumbnailBadgeViewModel":{"text":"17:34"}}]}}]}},
"metadata":{"lockupMetadataViewModel":{"title":{"content":"Opus 5.5 + Creatorize = 50 Youtube Shorts on Autopilot"}}}}},
{"lockupViewModel":{"contentImage":{"thumbnailViewModel":{
"image":{"sources":[{"url":"https://i.ytimg.com/vi/zzzzzzzzzzz/hq720.jpg"}]},
"overlays":[{"thumbnailBottomOverlayViewModel":{"badges":[{"thumbnailBadgeViewModel":{"text":"03:00:14"}}]}}]}},
"metadata":{"lockupMetadataViewModel":{"title":{"content":"Live stream"}}}}}],
"macroMarkersListItemRenderer":{"title":{"simpleText":"Introduction to Creatorize"},"timeDescription":{"simpleText":"0:00"}},
"macroMarkersListItemRenderer":{"title":{"simpleText":"Philosophy and results"},"timeDescription":{"simpleText":"0:35"}}}};
</script>`;

await test("channel page: name, handle, description", () => {
  const parsed = parseChannelPage(SAMPLE_CHANNEL_HTML);
  assert.equal(parsed.name, "g russ");
  assert.equal(parsed.handle, "@thegruss-i8w");
  assert.equal(parsed.channelId, "UCXvdrBvoz_T36afkGrgIHfg");
  assert.ok(parsed.description.includes("Join Now"));
});

await test("channel page: video id, title, runtime bind together", () => {
  const videos = parseVideoCatalogue(SAMPLE_CHANNEL_HTML);
  assert.equal(videos.length, 3);
  const first = videos.find((video) => video.id === "xj1WSzC0VfA");
  assert.ok(first, "first video found");
  assert.equal(first.duration, "25:29");
  assert.equal(first.durationSeconds, 1529);
  assert.equal(first.views, "1.2K");
  assert.equal(first.published, "4 hours ago");
  assert.ok(first.title.includes("Stickman"));
});

await test("channel page: chapters", () => {
  const chapters = extractChapters(SAMPLE_CHANNEL_HTML);
  assert.equal(chapters.length, 2);
  assert.equal(chapters[0].title, "Introduction to Creatorize");
  assert.equal(chapters[1].at, "0:35");
});

await test("durations: summary and format buckets", () => {
  const videos = parseVideoCatalogue(SAMPLE_CHANNEL_HTML);
  const summary = summarizeDurations(videos);
  assert.equal(summary.count, 3);
  assert.equal(summary.min, 1054);
  assert.equal(summary.max, 10814);
  const buckets = classifyFormats(videos);
  assert.equal(buckets.long.length, 2);
  assert.equal(buckets.livestream.length, 1);
  assert.equal(buckets.short.length, 0);
});

await test("durations: helpers round-trip", () => {
  assert.equal(durationToSeconds("25:29"), 1529);
  assert.equal(durationToSeconds("1:02:03"), 3723);
  assert.equal(formatDuration(1529), "25:29");
  assert.equal(formatDuration(3723), "1:02:03");
});

await test("titles: formulas and clusters", () => {
  const titles = [
    "Opus 5.5 + Creatorize = MEGA Viral Stickman Animations! (Step-by-Step Guide)",
    "Opus 5.5 + Creatorize = GIGA Viral Youtube Shorts On Autopilot!",
    "Sonnet 5.5 + Creatorize = EASY Faceless 3D Documentaries (Full Guide)",
    "How Opus 5.5 Runs a Faceless Documentary Channel (Fully Automated)",
  ];
  const formulas = deriveTitleFormulas(titles);
  assert.ok(formulas.length >= 1, "at least one recurring formula");
  assert.equal(formulas[0].count, 3);
  assert.equal(formulas[0].formula, "<MODEL> + <PRODUCT> = <INTENS> <TOPIC>");
  const clusters = deriveTopicClusters(titles);
  assert.ok(clusters.some((cluster) => cluster.term === "creatorize"));
});

// ------------------------------------------------------------------- plan ---

await test("plan: both templates exist and are well formed", () => {
  const templates = listTemplates();
  assert.ok(templates.length >= 2);
  const ids = templates.flatMap((template) => template.key);
  assert.ok(ids.includes("tutorial"));
  assert.ok(ids.includes("documentary"));
});

await test("plan: segment ids are legal Hypit segment names", () => {
  for (const format of ["tutorial", "documentary"]) {
    const plan = buildPlan({ topic: "A topic", format });
    for (const section of plan.sections) {
      assert.match(section.id, /^[a-z][a-z0-9_-]{0,63}$/, `${format}/${section.id}`);
      assert.notEqual(section.id, "script", "`script` is reserved by Hypit");
    }
  }
});

await test("plan: runtime follows the channel band", () => {
  const spec = {
    longform: { band: { recommendedTargetSeconds: 1462 } },
    catalogue: { videoCount: 30 },
  };
  const rhythm = deriveEpisodeRhythm(spec);
  assert.equal(rhythm.targetSeconds, 1462);
  const plan = buildPlan({ topic: "A topic", format: "tutorial", spec });
  assert.equal(plan.target.seconds, 1462);
  assert.ok(plan.sections.length >= 5);
  const sum = plan.sections.reduce((total, section) => total + section.targetSeconds, 0);
  assert.ok(Math.abs(sum - 1462) < 60, "section seconds roughly cover the target");
});

await test("plan: every section has a job, beats and B-roll briefs", () => {
  const plan = buildPlan({ topic: "A topic", format: "documentary" });
  for (const section of plan.sections) {
    assert.ok(section.purpose, `${section.id} has a purpose`);
    assert.ok(section.beats.length > 0, `${section.id} has beats`);
    assert.ok(section.broll.length > 0, `${section.id} has B-roll briefs`);
  }
});

await test("plan: audit catches an unscripted episode and a drift", () => {
  const plan = buildPlan({ topic: "A topic", format: "tutorial" });
  const before = auditPlan(plan);
  assert.equal(before.ok, false);
  assert.equal(before.unscripted, plan.sections.length);

  const scripted = applyScript(plan, {
    sections: Object.fromEntries(plan.sections.map((section) => [section.id, "A short line."])),
  });
  const after = auditPlan(scripted.plan);
  assert.equal(after.ok, true);
  assert.ok(after.findings.some((finding) => finding.level === "warn"));
});

// ------------------------------------------------------------------ svml ---

await test("svml: writer emits unquoted brace references", () => {
  const writer = new XmlWriter();
  writer.leaf("thing", { id: "x", ref: "{canvas.bounds}", text: "hello" });
  assert.equal(writer.toString(), '<thing id="x" ref={canvas.bounds} text="hello"/>');
});

await test("svml: script body escapes text but not quotes", () => {
  const source = buildLongformSource({
    sections: [{ id: "hook", spoken: "The creator's line & more <than> this." }],
  });
  assert.ok(source.includes("The creator's line"), "a Script body keeps its apostrophes literal");
  assert.ok(source.includes("&amp;"), "an ampersand is escaped");
  assert.ok(source.includes("&lt;than&gt;"), "angle brackets are escaped");
  assert.ok(!source.includes("</HOST>"), "a Role Cue is never closed");
  assert.ok(source.includes("<HOST> "), "the role marker opens the turn");
});

await test("svml: recipe keeps numeric strings quoted", () => {
  const recipe = buildRecipeSheet();
  assert.ok(recipe.includes('padding: "0"'), "padding stays a string");
  assert.ok(recipe.includes("karaoke: current"), "karaoke uses a legal value");
  assert.ok(!recipe.includes("karaoke: on"));
});

await test("svml: source declares one window per section, inside the timeline", () => {
  const plan = buildPlan({ topic: "A topic", format: "tutorial" });
  const sections = plan.sections.map((section) => ({ id: section.id, spoken: "Words." }));
  const source = buildLongformSource({ sections });
  const timelineStart = source.indexOf("<time:Timeline");
  const timelineEnd = source.indexOf("</time:Timeline>");
  for (const section of sections) {
    assert.ok(
      source.indexOf(`<time:Window id="${section.id}"`) > timelineStart &&
        source.indexOf(`<time:Window id="${section.id}"`) < timelineEnd,
      `${section.id} window is inside the timeline`,
    );
  }
  assert.ok(source.includes("</time:Timeline>"), "the timeline is closed, not self-closing");
});

await test("svml: run targets a source export", () => {
  const run = buildRun({});
  assert.ok(run.includes('<target output="final.video"/>'));
  assert.ok(run.includes('<author source="../authors/episode.svml"/>'));
});

// ---------------------------------------------------------------- author ---

await test("author: writes a runnable project and applies a script", async () => {
  const root = await mkdtemp(join(tmpdir(), "creatorize-test-"));
  try {
    const plan = buildPlan({ topic: "Test Episode", format: "tutorial" });
    const scripted = applyScript(plan, {
      sections: Object.fromEntries(plan.sections.map((section) => [section.id, "Some words for this section."])),
    });
    const result = await writeProject(root, scripted.plan, {});

    const manifest = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
    assert.equal(manifest.hypit.project, true);

    const source = await readFile(result.layout.authors + "/episode.svml", "utf8");
    assert.ok(source.includes("<script id=\"story\">"));
    assert.ok(source.includes("Some words for this section."));

    const recipe = await readFile(result.layout.recipes + "/longform.svs", "utf8");
    assert.ok(recipe.includes("caption.primary"));

    const run = await readFile(result.layout.runs + "/episode.svrun", "utf8");
    assert.ok(run.includes("../authors/episode.svml"));
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

await test("author: b-roll manifest is read back and placed", async () => {
  const root = await mkdtemp(join(tmpdir(), "creatorize-test-"));
  try {
    const plan = buildPlan({ topic: "Test Episode", format: "tutorial" });
    await mkdir(join(root, "assets", "broll"), { recursive: true });
    await writeFile(
      join(root, "assets", "broll", "broll.json"),
      JSON.stringify([
        { id: "hook-b1", sectionId: "cold-open", atSeconds: 2, durationSeconds: 4, path: `${root}/assets/broll/hook-b1.mp4` },
      ]),
      "utf8",
    );
    const manifest = await readBrollManifest(root);
    assert.equal(manifest.length, 1);

    const result = await writeProject(root, plan, {});
    const source = await readFile(result.layout.authors + "/episode.svml", "utf8");
    assert.ok(source.includes("<visual:Clip id=\"shot-hook-b1\""), "the clip is in the picture track");
    assert.ok(source.includes("shot-hook-b1"), "the clip has its own window");
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

await test("author: the alignment run targets only the word timings", async () => {
  const root = await mkdtemp(join(tmpdir(), "creatorize-test-"));
  try {
    const plan = buildPlan({ topic: "Test Episode", format: "tutorial" });
    const run = await writeAlignmentRun(root, plan.sections);
    const text = await readFile(run.path, "utf8");
    assert.ok(text.includes('<target output="align-cold-open.alignment"/>'));
    assert.ok(!text.includes("final.video"), "the picture is not part of an alignment run");
    assert.equal(run.targets.length, plan.sections.length);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

await test("author: the reuse run claims only what the earlier build produced", async () => {
  const root = await mkdtemp(join(tmpdir(), "creatorize-test-"));
  try {
    const plan = buildPlan({ topic: "Test Episode", format: "tutorial" });
    const available = new Set([
      "narration-cold-open-media.media",
      "narration-cold-open-media.domain",
      "align-cold-open.alignment",
    ]);
    const run = await writeReuseRun(root, "bld_test", plan.sections, { availableOutputs: available });
    const text = await readFile(run.path, "utf8");
    assert.ok(text.includes('build="bld_test"'));
    assert.ok(text.includes('output="align-cold-open.alignment"'));
    assert.ok(!text.includes("align-results.alignment"), "an absent output is not claimed");
    assert.ok(run.missing.length > 0, "the gaps are reported");
    assert.equal(run.records.length, 3);
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

// ------------------------------------------------------------------ deps ---

await test("deps: the published package list excludes the unpublished ones", () => {
  assert.ok(ALL_PACKAGES.includes("@hypit/caption-fine"));
  assert.ok(ALL_PACKAGES.includes("@fontsource-variable/inter"));
  assert.ok(!ALL_PACKAGES.includes("@hypit/text"), "@hypit/text is not published standalone");
  assert.ok(!ALL_PACKAGES.includes("@hypit/recipe"), "@hypit/recipe is not published standalone");
});

console.log(`\n  ${passed} passed, ${failed} failed\n`);
process.exit(failed === 0 ? 0 : 1);
